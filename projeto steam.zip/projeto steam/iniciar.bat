@echo off
title Steam Epic Bridge - Inicializador
echo ===================================================
echo        Inicializando Steam Epic Bridge...
echo ===================================================
echo.

:: Verifica se o Python esta instalado
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERRO] O Python nao foi encontrado no seu sistema.
    echo Por favor, instale o Python 3.10 ou superior e marque "Add Python to PATH".
    echo Acesse: https://www.python.org
    echo.
    pause
    exit /b
)

:: Instala as dependencias caso estejam faltando
echo Verificando e instalando dependencias (requirements.txt)...
python -m pip install -r requirements.txt --quiet
if %errorlevel% neq 0 (
    echo [AVISO] Algumas dependencias nao puderam ser instaladas automaticamente.
    echo Tentando executar mesmo assim...
)

echo.
echo [OK] Tudo pronto! Iniciando a Interface Grafica...
echo.

:: Inicia o app em segundo plano
start "" python SteamEpicBridge.py gui
exit
