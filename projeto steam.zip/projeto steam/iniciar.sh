#!/bin/bash
# Script de inicializacao automatica do Steam Epic Bridge para Linux/macOS

echo "==================================================="
echo "       Inicializando Steam Epic Bridge..."
echo "==================================================="
echo ""

# Verifica se o Python3 esta instalado
if ! command -v python3 &> /dev/null; then
    echo "[ERRO] Python3 nao encontrado no seu sistema."
    echo "Por favor, instale o Python 3.10 ou superior através do gerenciador de pacotes."
    echo "Exemplo (Ubuntu/Debian): sudo apt install python3 python3-pip python3-tk"
    echo ""
    read -p "Pressione [Enter] para sair..."
    exit 1
fi

# Instala as dependencias do requirements.txt
echo "Verificando e instalando dependencias (requirements.txt)..."
python3 -m pip install -r requirements.txt --user --quiet
if [ $? -ne 0 ]; then
    echo "[AVISO] Nao foi possivel instalar as dependencias automaticamente."
    echo "Tentando executar o aplicativo mesmo assim..."
fi

echo ""
echo "[OK] Tudo pronto! Iniciando a Interface Grafica..."
echo ""

# Inicia o app
python3 SteamEpicBridge.py gui &
exit 0
