# 🎮 Como Usar o Steam Epic Bridge

## O que é?
O Steam Epic Bridge sincroniza seus jogos da Epic Games Store para a biblioteca do Steam como atalhos. Assim, você pode acessar todos os seus jogos de um lugar só.

---

## Primeiro Uso (Passo a Passo)

### 1. Abrir a Interface
```bash
python -m steam_epic_bridge.main gui
```

### 2. Conectar sua Conta Epic
Para a segurança da sua conta, a Epic expira o código de login em **alguns segundos**. Portanto, você precisará ser rápido:

1. Na janela do programa, clique em **"Conectar Conta Epic"**.
2. Uma nova janela de login abrirá. Deixe-a aberta e clique no botão **"1. Abrir Navegador"**.
3. Faça seu login normalmente na Epic Games.
4. Assim que aparecer uma tela branca com um texto esquisito, aperte:
   - `Ctrl + A` (seleciona tudo)
   - `Ctrl + C` (copia)
5. **IMEDIATAMENTE** volte para a janela do programa, clique na caixa de texto e aperte `Ctrl + V` (colar).
6. Clique em **"3. Autenticar"**. O programa achará o código sozinho!

### 3. Sincronizar
- **Feche o Steam** completamente (ícone perto do relógio do Windows).
- Na janela do programa, desmarque "Executar primeiro em dry-run".
- Clique em **"Sincronizar"**.
- Reabra o Steam — seus jogos estarão na biblioteca!

---

## Funcionalidades

| Botão | O que faz |
|-------|-----------|
| **Sincronizar** | Adiciona jogos da Epic ao Steam |
| **Diagnosticar** | Verifica se tudo está configurado |
| **Limpar Atalhos** | Remove todos os jogos da Epic do Steam |
| **Restaurar Backup** | Desfaz a última sincronização |
| **Conectar Conta Epic** | Vincula sua conta da Epic Games |

---

## Opções

- **Dry-run**: Mostra o que seria feito sem alterar nada (marque para testar antes)
- **Apenas instalados**: Sincroniza somente jogos que já estão instalados no PC
- **SteamGridDB API Key**: Cole uma chave gratuita do [steamgriddb.com](https://www.steamgriddb.com) para baixar capas automaticamente

---

## Solução de Problemas

| Problema | Solução |
|----------|---------|
| "Steam está aberto" | Feche o Steam completamente pelo ícone na bandeja |
| "O código SID expirou" | Repita o processo de login sendo **mais rápido** no `Ctrl+V` |
| "Legendary não encontrado" | Execute `pip install legendary-gl` |
| Capas não aparecem | Configure a chave do SteamGridDB |
