# -*- mode: python ; coding: utf-8 -*-
import os
from pathlib import Path

# Calcula a raiz do projeto relativa a este arquivo spec
spec_root = Path(__file__).resolve().parent
project_root = spec_root.parent

a = Analysis(
    [str(project_root / 'SteamEpicBridge.py')],
    pathex=[str(project_root)],
    binaries=[(str(project_root / 'steam_epic_bridge' / 'bin' / 'legendary.exe'), 'bin')],
    datas=[],
    hiddenimports=['vdf', 'psutil', 'requests', 'click', 'rich', 'PIL'],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='SteamEpicBridge',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
