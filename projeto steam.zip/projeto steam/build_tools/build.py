import os
import subprocess
from pathlib import Path

def build():
    print("Iniciando build do Steam Epic Bridge...")
    
    # Caminho base (agora dentro de build_tools)
    script_dir = Path(__file__).resolve().parent
    project_root = script_dir.parent
    main_script = project_root / "SteamEpicBridge.py"
    
    if not main_script.exists():
        print(f"Erro: {main_script} nao encontrado.")
        return

    # Comando PyInstaller
    # Rodamos o PyInstaller a partir da raiz do projeto para manter consistencia
    command = [
        "python", "-m", "PyInstaller",
        "--noconfirm",
        "--onefile",
        "--console",  # CLI principal
        "--name", "SteamEpicBridge",
        "--add-binary", f"{project_root / 'steam_epic_bridge' / 'bin' / 'legendary.exe'};bin",
        "--hidden-import", "vdf",
        "--hidden-import", "psutil",
        "--hidden-import", "requests",
        "--hidden-import", "click",
        "--hidden-import", "rich",
        "--hidden-import", "PIL",
        str(main_script)
    ]

    print(f"Executando na raiz: {project_root}")
    print(f"Comando: {' '.join(command)}")
    try:
        # Muda para a raiz do projeto para rodar o build
        subprocess.run(command, check=True, cwd=str(project_root))
        print("\nBuild concluido com sucesso! O executavel esta na pasta 'dist' na raiz do projeto.")
    except subprocess.CalledProcessError as e:
        print(f"\nErro no build: {e}")
    except FileNotFoundError:
        print("\nErro: PyInstaller nao encontrado. Instale com 'pip install pyinstaller'.")

if __name__ == "__main__":
    build()
