import sys
from steam_epic_bridge.main import cli

if __name__ == "__main__":
    cli()
