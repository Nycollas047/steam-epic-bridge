"""
Testes unitários do Steam Epic Bridge.
Execute com:  python -m pytest tests/ -v

Cobre:
- compute_appid (função pública, antes era privada _entry_for_game)
- Sufixos corretos dos arquivos de artwork para atalhos não-Steam
- Leitura, escrita e idempotência do shortcuts.vdf
- Garantia que sync.py não usa importações privadas
"""
from __future__ import annotations
from pathlib import Path
import pytest
import vdf


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_settings(tmp_path: Path):
    from steam_epic_bridge.config import Settings
    steam_root = tmp_path / "Steam"
    user_id = "12345678"
    (steam_root / "userdata" / user_id / "config" / "grid").mkdir(parents=True)
    return Settings(
        steam_root=steam_root, steam_user_id=user_id,
        legendary_bin="legendary", steamgriddb_api_key=None, debug=False,
    )


def _make_game(app_name: str = "Fortnite", title: str = "Fortnite"):
    from steam_epic_bridge.models import EpicGame
    return EpicGame(
        app_name=app_name, title=title,
        launch_command=f'legendary launch "{app_name}"',
        is_installed=True, install_path=r"C:\Games",
    )


# ---------------------------------------------------------------------------
# compute_appid — função pública
# ---------------------------------------------------------------------------

class TestComputeAppid:
    def test_retorna_inteiro(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import compute_appid
        assert isinstance(compute_appid(_make_settings(tmp_path), _make_game()), int)

    def test_determinismo(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import compute_appid
        s, g = _make_settings(tmp_path), _make_game()
        assert compute_appid(s, g) == compute_appid(s, g)

    def test_jogos_distintos_ids_distintos(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import compute_appid
        s = _make_settings(tmp_path)
        assert compute_appid(s, _make_game("Fortnite", "Fortnite")) != \
               compute_appid(s, _make_game("RocketLeague", "Rocket League"))

    def test_bit_31_setado(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import compute_appid
        appid = compute_appid(_make_settings(tmp_path), _make_game())
        # Verifica como valor unsigned (o bit 31 pode ser setado em signed negativo)
        assert (appid & 0x80000000) or (appid < 0)

    def test_serializavel_como_int32(self, tmp_path):
        """O appid gerado deve caber em struct '<i' (signed int32)."""
        import struct
        from steam_epic_bridge.steam_shortcuts import compute_appid
        appid = compute_appid(_make_settings(tmp_path), _make_game())
        try:
            struct.pack("<i", appid)
        except struct.error as e:
            pytest.fail(f"appid {appid} não é um int32 válido: {e}")


# ---------------------------------------------------------------------------
# Sufixos de artwork
# ---------------------------------------------------------------------------

class TestArtworkSufixos:
    def test_grid_sufixo_p(self):
        from steam_epic_bridge.artwork import IMAGE_TYPES
        assert IMAGE_TYPES["grid"][1] == "p"

    def test_hero_sufixo(self):
        from steam_epic_bridge.artwork import IMAGE_TYPES
        assert IMAGE_TYPES["hero"][1] == "_hero"

    def test_logo_sufixo(self):
        from steam_epic_bridge.artwork import IMAGE_TYPES
        assert IMAGE_TYPES["logo"][1] == "_logo"

    def test_nome_arquivo_grid_final(self):
        from steam_epic_bridge.artwork import IMAGE_TYPES
        _, s = IMAGE_TYPES["grid"]
        assert f"9999{s}.png" == "9999p.png"


# ---------------------------------------------------------------------------
# shortcuts.vdf
# ---------------------------------------------------------------------------

class TestShortcuts:
    def test_adiciona_novo(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games
        c, sk, _ = add_games(_make_settings(tmp_path), [_make_game()])
        assert c == 1 and sk == 0

    def test_idempotente(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games
        s, g = _make_settings(tmp_path), _make_game()
        add_games(s, [g])
        c2, sk2, _ = add_games(s, [g])
        assert c2 == 0 and sk2 == 1

    def test_backup_gerado(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games
        s = _make_settings(tmp_path)
        add_games(s, [_make_game()])
        _, _, bak = add_games(s, [_make_game("RL", "Rocket League")])
        assert bak and bak.exists()

    def test_remove_atalhos(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games, remove_epic_shortcuts
        s = _make_settings(tmp_path)
        add_games(s, [_make_game()])
        assert remove_epic_shortcuts(s) == 1

    def test_vdf_valido(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games
        s = _make_settings(tmp_path)
        add_games(s, [_make_game()])
        with s.shortcuts_path.open("rb") as f:
            assert "shortcuts" in vdf.binary_load(f)


# ---------------------------------------------------------------------------
# sync.py sem importações privadas
# ---------------------------------------------------------------------------

class TestSyncLimpo:
    def test_sem_entry_for_game_privado(self):
        import inspect, steam_epic_bridge.sync as m
        assert "_entry_for_game" not in inspect.getsource(m)

    def test_usa_compute_appid(self):
        import inspect, steam_epic_bridge.sync as m
        assert "compute_appid" in inspect.getsource(m)


# ---------------------------------------------------------------------------
# Suporte multiplataforma (Linux / macOS)
# ---------------------------------------------------------------------------

class TestMultiplatformLaunch:
    def test_linux_launch_installed_game(self, tmp_path, monkeypatch):
        import sys
        from steam_epic_bridge.steam_shortcuts import _build_exe_and_launch
        
        # Simula plataforma Linux/macOS
        monkeypatch.setattr(sys, "platform", "linux")
        
        settings = _make_settings(tmp_path)
        settings.legendary_bin = "/usr/bin/legendary"
        
        from steam_epic_bridge.models import EpicGame
        installed_game = EpicGame(
            app_name="Fortnite",
            title="Fortnite",
            launch_command="legendary launch Fortnite",
            is_installed=True,
            install_path="/home/user/games"
        )
        
        exe, opts, start_dir = _build_exe_and_launch(settings, installed_game)
        assert exe == "/usr/bin/legendary"
        assert opts == 'launch "Fortnite"'
        assert start_dir == "/home/user/games"

    def test_linux_launch_uninstalled_game(self, tmp_path, monkeypatch):
        import sys
        from steam_epic_bridge.steam_shortcuts import _build_exe_and_launch
        
        monkeypatch.setattr(sys, "platform", "linux")
        
        settings = _make_settings(tmp_path)
        
        from steam_epic_bridge.models import EpicGame
        uninstalled_game = EpicGame(
            app_name="Fortnite",
            title="Fortnite",
            launch_command="com.epicgames.launcher://apps/Fortnite?action=launch",
            is_installed=False,
            install_path=None
        )
        
        exe, opts, start_dir = _build_exe_and_launch(settings, uninstalled_game)
        assert exe == "xdg-open"
        assert opts == '"com.epicgames.launcher://apps/Fortnite?action=launch"'
        assert start_dir == "/tmp"
