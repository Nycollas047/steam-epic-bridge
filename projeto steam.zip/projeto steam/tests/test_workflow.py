from __future__ import annotations

from pathlib import Path


def _make_settings(tmp_path: Path):
    from steam_epic_bridge.config import Settings
    from steam_epic_bridge.discovery import DiscoveryResult

    steam_root = tmp_path / "Steam"
    user_id = "12345678"
    (steam_root / "userdata" / user_id / "config" / "grid").mkdir(parents=True)
    return Settings(
        steam_root=steam_root,
        steam_user_id=user_id,
        legendary_bin="legendary",
        steamgriddb_api_key=None,
        debug=False,
        discovery=DiscoveryResult(),
    )


def _make_game(app_name: str = "Fortnite", title: str = "Fortnite", installed: bool = True):
    from steam_epic_bridge.models import EpicGame

    launch_command = (
        f'legendary launch "{app_name}"'
        if installed
        else f"com.epicgames.launcher://apps/{app_name}?action=launch&silent=true"
    )
    return EpicGame(
        app_name=app_name,
        title=title,
        launch_command=launch_command,
        is_installed=installed,
        install_path=r"C:\Games" if installed else None,
    )


class TestPlanningAndRestore:
    def test_plan_add_games_matches_expected(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games, plan_add_games

        settings = _make_settings(tmp_path)
        add_games(settings, [_make_game("Fortnite", "Fortnite")])
        created, skipped = plan_add_games(
            settings,
            [_make_game("Fortnite", "Fortnite"), _make_game("RL", "Rocket League")],
        )
        assert created == 1
        assert skipped == 1

    def test_restore_backup_recovers_previous_file(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import add_games, restore_shortcuts_backup

        settings = _make_settings(tmp_path)
        add_games(settings, [_make_game("Fortnite", "Fortnite")])
        original_bytes = settings.shortcuts_path.read_bytes()

        add_games(settings, [_make_game("RL", "Rocket League")])
        changed_bytes = settings.shortcuts_path.read_bytes()
        assert changed_bytes != original_bytes

        backup = restore_shortcuts_backup(settings)
        restored_bytes = settings.shortcuts_path.read_bytes()

        assert backup.exists()
        assert restored_bytes == original_bytes


class TestDoctorAndSync:
    def test_doctor_reports_backup_availability(self, tmp_path, monkeypatch):
        from steam_epic_bridge.sync import doctor

        settings = _make_settings(tmp_path)
        settings.shortcuts_path.write_bytes(b"")
        settings.shortcuts_path.with_suffix(".vdf.bak").write_bytes(b"backup")

        monkeypatch.setattr("steam_epic_bridge.sync.ensure_authenticated", lambda settings: None)
        monkeypatch.setattr("steam_epic_bridge.sync.list_games", lambda settings: [])

        result = doctor(settings)
        assert result["backup_available"] is True
        assert result["epic_authenticated"] is True
        assert result["epic_games"] == 0

    def test_sync_dry_run_does_not_write(self, tmp_path, monkeypatch):
        from steam_epic_bridge.sync import sync_library

        settings = _make_settings(tmp_path)
        before = settings.shortcuts_path.read_bytes() if settings.shortcuts_path.exists() else None

        monkeypatch.setattr("steam_epic_bridge.sync.ensure_authenticated", lambda settings: None)
        monkeypatch.setattr(
            "steam_epic_bridge.sync.list_games",
            lambda settings, **kwargs: [_make_game("Fortnite", "Fortnite"), _make_game("RL", "Rocket League")],
        )

        result = sync_library(settings, dry_run=True)
        after = settings.shortcuts_path.read_bytes() if settings.shortcuts_path.exists() else None

        assert result.planned == 2
        assert result.created == 0
        assert result.skipped == 0
        assert before == after

    def test_sync_installed_only_filters_uninstalled(self, tmp_path, monkeypatch):
        from steam_epic_bridge.sync import sync_library

        settings = _make_settings(tmp_path)
        monkeypatch.setattr("steam_epic_bridge.sync.ensure_authenticated", lambda settings: None)
        monkeypatch.setattr(
            "steam_epic_bridge.sync.list_games",
            lambda settings, **kwargs: [
                _make_game("Fortnite", "Fortnite", installed=True),
                _make_game("UEFN", "Unreal Editor", installed=False),
            ],
        )

        result = sync_library(settings, dry_run=True, installed_only=True)
        assert result.planned == 1

    def test_sync_engine_dry_run_does_not_create_shortcuts(self, tmp_path, monkeypatch):
        from steam_epic_bridge.core import SyncEngine

        settings = _make_settings(tmp_path)
        engine = SyncEngine(settings)

        monkeypatch.setattr("steam_epic_bridge.core.ensure_authenticated", lambda settings: None)
        monkeypatch.setattr(
            "steam_epic_bridge.core.list_games",
            lambda settings, **kwargs: [_make_game("Fortnite", "Fortnite")],
        )

        result = engine.sync(dry_run=True)
        assert result.planned == 1
        assert result.created == 0
        assert not settings.shortcuts_path.exists()

    def test_repair_library_without_grid_dir_returns_zeroes(self, tmp_path):
        from steam_epic_bridge.steam_shortcuts import repair_library

        settings = _make_settings(tmp_path)
        settings.grid_dir.rmdir()

        result = repair_library(settings)
        assert result["rebuilt_icons"] == 0
        assert result["updated_paths"] == 0
        assert result["cleaned_files"] == 0

    def test_update_artwork_paths_converts_icon_to_ico(self, tmp_path):
        from PIL import Image
        from steam_epic_bridge.steam_shortcuts import add_games, compute_appid, update_artwork_paths

        settings = _make_settings(tmp_path)
        game = _make_game("Fortnite", "Fortnite")
        add_games(settings, [game])

        appid = compute_appid(settings, game) & 0xFFFFFFFF
        png_icon = settings.grid_dir / f"{appid}_icon.png"
        with Image.new("RGBA", (32, 32), (255, 0, 0, 255)) as image:
            image.save(png_icon, format="PNG")

        updated = update_artwork_paths(settings)
        ico_icon = settings.grid_dir / f"{appid}_icon.ico"

        assert updated >= 1
        assert ico_icon.exists()

    def test_repair_library_rebuilds_icon_from_grid_art(self, tmp_path):
        from PIL import Image
        from steam_epic_bridge.steam_shortcuts import add_games, compute_appid, repair_library

        settings = _make_settings(tmp_path)
        game = _make_game("Fortnite", "Fortnite")
        add_games(settings, [game])
        appid = compute_appid(settings, game) & 0xFFFFFFFF

        grid_image = settings.grid_dir / f"{appid}p.png"
        with Image.new("RGBA", (64, 64), (0, 255, 0, 255)) as image:
            image.save(grid_image, format="PNG")

        result = repair_library(settings)
        assert result["rebuilt_icons"] >= 1
        assert (settings.grid_dir / f"{appid}_icon.ico").exists()

    def test_reset_all_restores_backup_and_clears_cache(self, tmp_path, monkeypatch):
        from steam_epic_bridge.sync import reset_all
        from steam_epic_bridge.steam_shortcuts import add_games

        settings = _make_settings(tmp_path)
        add_games(settings, [_make_game("Fortnite", "Fortnite")])
        original_bytes = settings.shortcuts_path.read_bytes()
        add_games(settings, [_make_game("RL", "Rocket League")])

        monkeypatch.setattr("steam_epic_bridge.sync.clear_artwork_cache", lambda: 1)

        result = reset_all(settings)

        assert result.restored_backup is True
        assert result.backup_path is not None
        assert result.cleared_cache == 1
        assert settings.shortcuts_path.read_bytes() == original_bytes

    def test_reset_all_falls_back_to_removing_epic_shortcuts(self, tmp_path, monkeypatch):
        from steam_epic_bridge.sync import reset_all
        from steam_epic_bridge.steam_shortcuts import add_games, existing_shortcuts_count

        settings = _make_settings(tmp_path)
        add_games(settings, [_make_game("Fortnite", "Fortnite"), _make_game("RL", "Rocket League")])
        backup_path = settings.shortcuts_path.with_suffix(".vdf.bak")
        if backup_path.exists():
            backup_path.unlink()

        monkeypatch.setattr("steam_epic_bridge.sync.clear_artwork_cache", lambda: 0)

        result = reset_all(settings)

        assert result.restored_backup is False
        assert result.removed_shortcuts == 2
        assert existing_shortcuts_count(settings) == 0





class TestArtworkMatching:
    def test_candidate_search_terms_strip_common_edition_suffixes(self):
        from steam_epic_bridge.artwork import _candidate_search_terms

        game = _make_game("BioshockInfinite", "BioShock Infinite: Complete Edition")
        terms = _candidate_search_terms(game)

        assert "BioShock Infinite: Complete Edition" in terms
        assert "BioShock Infinite" in terms
