# 🎮 Steam Epic Bridge

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white" alt="Python Version" />
  <img src="https://img.shields.io/badge/Platform-Windows%20%7C%20Linux-0078D6?style=for-the-badge&logo=windows&logoColor=white" alt="Platforms Supported" />
  <img src="https://img.shields.io/badge/License-MIT-green?style=for-the-badge" alt="License" />
</p>

**Steam Epic Bridge** is a beautiful, lightweight, and cross-platform synchronization tool that seamlessly integrates your entire **Epic Games Store** library directly into **Steam** as non-Steam game shortcuts. 

The application automatically scrapes, matches, and downloads high-resolution vertical covers, landscape banners, logos, and custom icons in modern formats to make your unified Steam library look absolutely stunning.

---

## ✨ Key Features

- 🔄 **1-Click Synchronization**: Add your entire Epic Games library (both installed and uninstalled games) to Steam in a single click.
- 🎨 **Automatic Art & Covers**: Direct integration with the **SteamGridDB** API to automatically download vertical posters, horizontal grids (hero), game logos, and custom icons.
- 🌐 **Fully Cross-Platform**: Runs natively on both **Windows** and **Linux** (including full compatibility with Flatpak Steam directories like on the **Steam Deck**!).
- 🔒 **Secure & Graphical Login**: Zero terminal hassle! Authenticate securely through a beautiful, integrated OAuth login wizard (`EpicLoginDialog`).
- 🛠️ **Artwork Doctor & Repair Tools**: An integrated suite to detect stretched cover aspect ratios, low-resolution assets, fix broken game execution paths, clear duplicate/orphan images, and rebuild missing icons.
- 📦 **Zero-Config Launchers**: Comes pre-packaged with easy one-click scripts (`iniciar.bat` / `iniciar.sh`) that automatically bootstrap your virtual environment and install missing dependencies.

---

## 🚀 Quick Start

We have made launching the application as effortless as possible. You do not need to install python packages manually.

### 💻 On Windows
1. Double-click the **[`iniciar.bat`](file:///c:/Users/nycol/Downloads/projeto%20steam/iniciar.bat)** file.
2. The script will automatically create a virtual environment, install dependencies, and launch the graphical interface.

### 🐧 On Linux / Steam Deck
1. Open your terminal in the project directory.
2. Make the shell script executable and run it:
   ```bash
   chmod +x iniciar.sh
   ./iniciar.sh
   ```
3. The application GUI will launch automatically.

---

## 🔧 Step-by-Step Configuration Guide

Follow these simple steps to set up your unified library:

### Step 1: Set up Automatic Cover Art (SteamGridDB API)
To allow the app to download artwork automatically:
1. Go to [SteamGridDB](https://www.steamgriddb.com) and create a free account.
2. Navigate to **Preferences > API** and click **"Generate API Key"**.
3. Copy your generated API Key.
4. In the **Steam Epic Bridge** app, paste the key into the **"API Key"** field and click **Save**.

### Step 2: Connect your Epic Games Account
To fetch your games securely:
1. **Close Steam completely** before continuing.
2. Click the **"Connect Epic Account"** button in the application.
3. Click **"1. Open Epic Login Page"** to sign in through the official, secure Epic Games website on your default browser.
4. After signing in, you will see a JSON code on your browser tab (e.g., `{"sid": "..."}`). **Copy the entire text**.
5. Return to the application window, paste the copied code into the text input, and click **"2. Confirm & Authenticate"**.
6. Your Epic Games library is now successfully synchronized!

### Step 3: Run the Synchronizer
1. Ensure **Steam is closed** so your shortcuts can be saved correctly.
2. (Optional) Check **"Run first in dry-run mode"** to see what changes will be made without writing anything.
3. Click **"Sync All"**.
4. Open Steam and enjoy your perfectly unified library with gorgeous cover arts!

---

## 📂 Project Structure

```
├── iniciar.bat             # One-click launcher for Windows (Auto-bootstrap)
├── iniciar.sh              # One-click launcher for Linux (Auto-bootstrap)
├── SteamEpicBridge.py      # Main application entry point (CLI & GUI)
├── requirements.txt        # Core dependencies (Pillow, click, rich, vdf, etc.)
├── steam_epic_bridge/      # Core application source code
│   ├── gui.py              # Tkinter-based graphical user interface
│   ├── main.py             # Command Line Interface (CLI) controller
│   ├── sync.py             # Library synchronization and matching rules
│   ├── steam_shortcuts.py  # Reader & writer for Steam's binary shortcuts.vdf file
│   ├── discovery.py        # Auto-detection of Steam & Legendary installation paths
│   ├── config.py           # Local settings and directories manager
│   └── models.py           # Game and metadata data models
├── tests/                  # Complete suite of unit and integration tests
└── docs/                   # Help documentation and guides
```

---

## 🛠️ Development & Testing

This project includes a comprehensive suite of **28 automated tests** covering AppID generation, binary VDF parser idempotency, and discovery rules. To run tests locally, install development requirements and execute:

```bash
python -m pytest tests/ -v
```

---

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

*Made with ❤️ to simplify PC gaming and unify your game libraries beautifully, privately, and securely.* 🎮✨
