import os
import subprocess
import sys
from pathlib import Path

def register_task():
    """Registra uma tarefa no Agendador de Tarefas do Windows para rodar o sync diariamente."""
    if sys.platform != "win32":
        return False, "Agendamento automatico no Linux/macOS nao e suportado nativamente. Voce pode configurar um cronjob ou systemd timer executando 'steam_epic_bridge sync' manualmente."

    task_name = "SteamEpicBridgeSync"
    # Se estiver rodando como script, usa o interpretador python + o modulo.
    # Se for um .exe, usa o caminho do executavel.
    if getattr(sys, 'frozen', False):
        exe_path = sys.executable
        command = f'"{exe_path}" sync'
    else:
        python_exe = sys.executable
        module_path = Path(__file__).parent.parent
        command = f'"{python_exe}" -m steam_epic_bridge.main sync --no-artwork'

    # Comando para criar a tarefa no Windows: diariamente às 04h00.
    schtasks_cmd = [
        "schtasks", "/create", "/sc", "daily", "/tn", task_name,
        "/tr", command, "/st", "04:00", "/f"
    ]

    try:
        subprocess.run(schtasks_cmd, check=True, capture_output=True)
        return True, "Tarefa configurada para rodar diariamente às 04:00."
    except subprocess.CalledProcessError as e:
        return False, e.stderr.decode('utf-8', errors='replace')

def unregister_task():
    """Remove a tarefa do Agendador de Tarefas do Windows."""
    if sys.platform != "win32":
        return False, "Agendamento automatico nao e suportado nesta plataforma."

    task_name = "SteamEpicBridgeSync"
    schtasks_cmd = ["schtasks", "/delete", "/tn", task_name, "/f"]
    try:
        subprocess.run(schtasks_cmd, check=True, capture_output=True)
        return True, "Tarefa removida com sucesso."
    except subprocess.CalledProcessError as e:
        return False, e.stderr.decode('utf-8', errors='replace')
