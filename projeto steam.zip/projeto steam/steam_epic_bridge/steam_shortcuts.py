from __future__ import annotations

import binascii
import shutil
import sys
from pathlib import Path

import psutil
import vdf

from steam_epic_bridge.artwork import IMAGE_TYPES, ensure_ico_file
from steam_epic_bridge.config import APP_ID_PREFIX, SHORTCUT_TAG, Settings
from steam_epic_bridge.models import EpicGame


class SteamShortcutsError(RuntimeError):
    pass


# Prefixo que identifica comandos via protocolo URL da Epic (jogos não instalados).
_EPIC_URL_PREFIX = "com.epicgames.launcher://"


def is_steam_running() -> bool:
    """Verifica se o processo do Steam está em execução."""
    for proc in psutil.process_iter(["name"]):
        try:
            if proc.info["name"].lower() == "steam.exe" or proc.info["name"].lower() == "steam":
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return False


def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def _load_shortcuts(path: Path) -> dict:
    if not path.exists():
        return {"shortcuts": {}}
    try:
        with path.open("rb") as handle:
            payload = vdf.binary_load(handle)
        return payload or {"shortcuts": {}}
    except (OSError, Exception):
        # Se o arquivo estiver corrompido, retorna estrutura vazia para evitar crash
        return {"shortcuts": {}}


def _save_shortcuts(path: Path, payload: dict) -> None:
    _ensure_parent(path)
    with path.open("wb") as handle:
        vdf.binary_dump(payload, handle)


def backup_shortcuts(path: Path) -> Path | None:
    if not path.exists():
        return None
    backup = path.with_suffix(".vdf.bak")
    shutil.copy2(path, backup)
    return backup


def latest_backup_path(path: Path) -> Path:
    return path.with_suffix(".vdf.bak")


def restore_shortcuts_backup(settings: Settings) -> Path:
    path = ensure_shortcuts_file(settings)
    backup = latest_backup_path(path)
    if not backup.exists():
        raise SteamShortcutsError("Nenhum backup de shortcuts.vdf foi encontrado para restauracao.")
    shutil.copy2(backup, path)
    return backup


def _iter_entries(payload: dict) -> list[tuple[str, dict]]:
    shortcuts = payload.setdefault("shortcuts", {})
    return [(str(key), value) for key, value in shortcuts.items() if str(key).isdigit()]


def _next_index(payload: dict) -> str:
    existing = [int(key) for key, _ in _iter_entries(payload)]
    return str(max(existing, default=-1) + 1)


def _shortcut_id(game: EpicGame) -> str:
    return f"{APP_ID_PREFIX}{game.app_name}"


def _unsigned_appid(exe: str, appname: str) -> int:
    """Gera unsigned int32 com bit 31 setado (convenção Steam para atalhos não-Steam)."""
    return binascii.crc32(f"{exe}{appname}".encode("utf-8")) | 0x80000000


def _appid_for_entry(entry: dict) -> int:
    unsigned = _unsigned_appid(entry.get("exe", ""), entry.get("appname", ""))
    # Converte para signed int32: necessário para vdf.binary_dump (struct '<i').
    return unsigned if unsigned <= 0x7FFFFFFF else unsigned - 0x100000000



def _build_exe_and_launch(settings: Settings, game: EpicGame) -> tuple[str, str, str]:
    """Retorna (exe, launch_options, start_dir) conforme o tipo de launcher do jogo e o SO atual.

    - Jogos instalados: legendary launch direto (cmd.exe no Windows, legendary nativo no Linux).
    - Jogos não instalados: protocolo URL da Epic (explorer.exe no Windows, xdg-open no Linux).
    """
    if sys.platform != "win32":
        # Lógica para Linux / macOS (ex: Steam Deck)
        if game.launch_command.startswith(_EPIC_URL_PREFIX):
            # Jogos NÃO instalados: usa xdg-open para abrir o protocolo da Epic.
            exe = "xdg-open"
            launch_opts = f'"{game.launch_command}"'
            start_dir = "/tmp"
        else:
            # Jogos instalados: usa o legendary diretamente como executável.
            exe = settings.legendary_bin
            launch_opts = f'launch "{game.app_name}"'
            start_dir = game.install_path or "/tmp"
    else:
        # Lógica original para Windows
        if game.launch_command.startswith(_EPIC_URL_PREFIX):
            # Jogos NÃO instalados: usa explorer.exe para abrir a URL da Epic.
            exe = r'"C:\Windows\explorer.exe"'
            launch_opts = f'"{game.launch_command}"'
            start_dir = r"C:\Windows"
        else:
            # Jogos instalados: usa cmd.exe chamando legendary launch.
            exe = r'"C:\Windows\System32\cmd.exe"'
            legendary = settings.legendary_bin
            if " " in legendary:
                legendary = f'"{legendary}"'
            launch_opts = f'/c {legendary} launch "{game.app_name}"'
            start_dir = game.install_path or r"C:\Windows\System32"

    return exe, launch_opts, start_dir


def compute_appid(settings: Settings, game: EpicGame) -> int:
    """Retorna o appid que será gravado no shortcuts.vdf para o jogo Epic informado.

    Função pública para uso por outros módulos (ex.: artwork) sem acessar internos.
    """
    return int(_entry_for_game(settings, game)["appid"])


def _entry_for_game(settings: Settings, game: EpicGame) -> dict:
    exe, launch_opts, start_dir = _build_exe_and_launch(settings, game)
    unsigned_appid = _unsigned_appid(exe, game.title)
    
    entry = {
        "appname": game.title,
        "exe": exe,
        "StartDir": start_dir,
        "icon": "",
        "ShortcutPath": "",
        "LaunchOptions": launch_opts,
        "IsHidden": 0,
        "AllowDesktopConfig": 1,
        "AllowOverlay": 1,
        "OpenVR": 0,
        "Devkit": 0,
        "DevkitGameID": _shortcut_id(game),
        "LastPlayTime": 0,
        "FlatpakAppID": "",
        "tags": {"0": SHORTCUT_TAG, "1": _shortcut_id(game)},
    }
    # Converte unsigned para signed int32 para o campo appid do VDF
    entry["appid"] = unsigned_appid if unsigned_appid <= 0x7FFFFFFF else unsigned_appid - 0x100000000
    return entry


def ensure_shortcuts_file(settings: Settings) -> Path:
    if not settings.shortcuts_path:
        raise SteamShortcutsError("Nao foi possivel localizar a pasta userdata/config do Steam.")
    _ensure_parent(settings.shortcuts_path)
    if not settings.shortcuts_path.exists():
        _save_shortcuts(settings.shortcuts_path, {"shortcuts": {}})
    return settings.shortcuts_path


def add_games(settings: Settings, games: list[EpicGame]) -> tuple[int, int, Path | None]:
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    backup = backup_shortcuts(path)

    existing_names = {entry.get("appname", "").casefold() for _, entry in _iter_entries(payload)}
    created = 0
    skipped = 0

    for game in games:
        if game.title.casefold() in existing_names:
            skipped += 1
            continue
        payload["shortcuts"][_next_index(payload)] = _entry_for_game(settings, game)
        existing_names.add(game.title.casefold())
        created += 1

    _save_shortcuts(path, payload)
    return created, skipped, backup


def plan_add_games(settings: Settings, games: list[EpicGame]) -> tuple[int, int]:
    # Lê o arquivo se existir, sem criá-lo (dry-run não deve ter efeitos colaterais).
    path = settings.shortcuts_path
    payload = _load_shortcuts(path) if path and path.exists() else {"shortcuts": {}}
    existing_names = {entry.get("appname", "").casefold() for _, entry in _iter_entries(payload)}
    created = 0
    skipped = 0

    for game in games:
        if game.title.casefold() in existing_names:
            skipped += 1
            continue
        existing_names.add(game.title.casefold())
        created += 1

    return created, skipped


def remove_epic_shortcuts(settings: Settings) -> int:
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    original = dict(payload.get("shortcuts", {}))
    filtered: dict[str, dict] = {}
    removed = 0

    for _, entry in _iter_entries(payload):
        tags = entry.get("tags", {})
        tag_values = {str(value) for value in tags.values()}
        if SHORTCUT_TAG in tag_values:
            removed += 1
            
            # Limpa as imagens baixadas (artworks) para liberar espaço no disco
            appid = int(entry.get("appid", 0))
            if appid and settings.grid_dir and settings.grid_dir.exists():
                unsigned_appid = appid & 0xFFFFFFFF
                for steam_suffix in ["p", "_hero", "_logo", "_icon"]:
                    for ext in [".png", ".jpg", ".jpeg", ".ico"]:
                        img_path = settings.grid_dir / f"{unsigned_appid}{steam_suffix}{ext}"
                        try:
                            if img_path.exists():
                                img_path.unlink()
                        except OSError:
                            pass
                            
            continue
        filtered[str(len(filtered))] = entry

    if removed:
        backup_shortcuts(path)
        payload["shortcuts"] = filtered
        _save_shortcuts(path, payload)
    else:
        payload["shortcuts"] = original
    return removed


def existing_shortcuts_count(settings: Settings) -> int:
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    count = 0
    for _, entry in _iter_entries(payload):
        tags = entry.get("tags", {})
        if SHORTCUT_TAG in {str(value) for value in tags.values()}:
            count += 1
    return count


def clear_only_artwork(settings: Settings) -> int:
    """Deleta apenas os arquivos de imagem (Grid/Icon) para atalhos da Epic, sem remover os games."""
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    removed_files = 0

    if not settings.grid_dir or not settings.grid_dir.exists():
        return 0

    for _, entry in _iter_entries(payload):
        tags = entry.get("tags", {})
        if SHORTCUT_TAG in {str(value) for value in tags.values()}:
            appid = int(entry.get("appid", 0))
            if appid:
                unsigned_appid = appid & 0xFFFFFFFF
                for steam_suffix in ["p", "_hero", "_logo", "_icon"]:
                    for ext in [".png", ".jpg", ".jpeg", ".ico"]:
                        img_path = settings.grid_dir / f"{unsigned_appid}{steam_suffix}{ext}"
                        try:
                            if img_path.exists():
                                img_path.unlink()
                                removed_files += 1
                        except OSError:
                            pass
    return removed_files


def update_artwork_paths(settings: Settings, progress_callback: callable | None = None) -> int:
    """Atualiza o campo 'icon' dos atalhos na biblioteca Epic para apontar corretamente para os arquivos na pasta grid.
    Resolve problemas como quando a imagem baixada eh um .ico mas o atalho foi gravado como .png.
    """
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    
    if not settings.grid_dir or not settings.grid_dir.exists():
        return 0

    updated = 0
    entries = _iter_entries(payload)
    total = len(entries)
    for i, (_, entry) in enumerate(entries, 1):
        if progress_callback:
            progress_callback(f"Verificando icones: {entry.get('appname', 'Desconhecido')}", i, total)
        
        tags = entry.get("tags", {})
        if SHORTCUT_TAG in {str(value) for value in tags.values()}:
            appid = int(entry.get("appid", 0))
            if not appid:
                continue
                
            unsigned_appid = appid & 0xFFFFFFFF
            found_icon = ""
            # A ordem importa: preferimos .ico, depois .png, depois .jpg para icone na lateral do Steam
            for ext in [".ico", ".png", ".jpg", ".jpeg"]:
                img_path = settings.grid_dir / f"{unsigned_appid}_icon{ext}"
                if img_path.exists():
                    icon_path = img_path
                    if ext != ".ico":
                        converted = ensure_ico_file(img_path)
                        if converted:
                            icon_path = converted
                    found_icon = str(icon_path)
                    break
            
            if found_icon and entry.get("icon") != found_icon:
                entry["icon"] = found_icon
                updated += 1
            elif not found_icon and entry.get("icon"):
                # Se apagou a imagem, remove do atalho pra Steam n tentar carregar
                entry["icon"] = ""
                updated += 1

    if updated > 0:
        _save_shortcuts(path, payload)
        
    return updated


def rebuild_missing_icons(settings: Settings, progress_callback: callable | None = None) -> int:
    """Tenta recriar _icon.ico a partir de outras artes ja existentes no grid."""
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)

    if not settings.grid_dir or not settings.grid_dir.exists():
        return 0

    rebuilt = 0
    entries = _iter_entries(payload)
    total = len(entries)
    for i, (_, entry) in enumerate(entries, 1):
        if progress_callback:
            progress_callback(f"Reconstruindo icones: {entry.get('appname', 'Desconhecido')}", i, total)

        tags = entry.get("tags", {})
        if SHORTCUT_TAG not in {str(value) for value in tags.values()}:
            continue

        appid = int(entry.get("appid", 0))
        if not appid:
            continue

        unsigned_appid = appid & 0xFFFFFFFF
        icon_ico = settings.grid_dir / f"{unsigned_appid}_icon.ico"
        if icon_ico.exists():
            continue

        fallback_sources = [
            settings.grid_dir / f"{unsigned_appid}_icon.png",
            settings.grid_dir / f"{unsigned_appid}_icon.jpg",
            settings.grid_dir / f"{unsigned_appid}_icon.jpeg",
            settings.grid_dir / f"{unsigned_appid}p.png",
            settings.grid_dir / f"{unsigned_appid}p.jpg",
            settings.grid_dir / f"{unsigned_appid}p.jpeg",
            settings.grid_dir / f"{unsigned_appid}_logo.png",
            settings.grid_dir / f"{unsigned_appid}_logo.jpg",
            settings.grid_dir / f"{unsigned_appid}_logo.jpeg",
        ]

        for source in fallback_sources:
            converted = ensure_ico_file(source, destination=icon_ico)
            if converted and converted.exists():
                rebuilt += 1
                break

    return rebuilt

def _fix_path(original_path: str) -> str:
    """Tenta corrigir um caminho que não existe (ex: mudança de letra de drive)."""
    p = Path(original_path.strip('"'))
    try:
        if p.exists():
            return original_path
    except OSError:
        pass
        
    # 1. Tenta outras letras de drive se for um caminho absoluto
    if p.drive:
        for drive in "CDEFGHIJKLMNOPQRSTUVWXYZ":
            new_p = Path(f"{drive}:{p.as_posix()[2:]}")
            try:
                if new_p.exists():
                    return f'"{new_p}"' if " " in str(new_p) else str(new_p)
            except OSError:
                continue
                
    return original_path

def validate_shortcut_paths(settings: Settings, progress_callback: callable | None = None) -> int:
    """Verifica se os executáveis e pastas de início dos atalhos ainda existem."""
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    
    fixed = 0
    entries = _iter_entries(payload)
    total = len(entries)
    
    for i, (_, entry) in enumerate(entries, 1):
        if progress_callback:
            progress_callback(f"Validando caminhos: {entry.get('appname', 'Desconhecido')}", i, total)
        
        tags = entry.get("tags", {})
        if SHORTCUT_TAG not in {str(value) for value in tags.values()}:
            continue

        exe = entry.get("exe", "")
        start_dir = entry.get("StartDir", "")
        
        new_exe = _fix_path(exe)
        new_start = _fix_path(start_dir)
        
        if new_exe != exe or new_start != start_dir:
            entry["exe"] = new_exe
            entry["StartDir"] = new_start
            fixed += 1
            
    if fixed > 0:
        _save_shortcuts(path, payload)
    return fixed


def scan_and_fix_artworks(settings: Settings, progress_callback: callable | None = None) -> int:
    """Rastreia a pasta grid em busca de arquivos duplicados ou orfaos e limpa.
    Se um jogo tiver um .png e um .ico para o mesmo icone, deleta o .png e fica com o .ico.
    Retorna a quantidade de arquivos deletados.
    """
    path = ensure_shortcuts_file(settings)
    payload = _load_shortcuts(path)
    
    if not settings.grid_dir or not settings.grid_dir.exists():
        return 0

    removed_count = 0
    vdf_updated = False
    
    entries = _iter_entries(payload)
    total = len(entries)
    for i, (_, entry) in enumerate(entries, 1):
        if progress_callback:
            progress_callback(f"Limpando duplicatas: {entry.get('appname', 'Desconhecido')}", i, total)
            
        tags = entry.get("tags", {})
        if SHORTCUT_TAG not in {str(value) for value in tags.values()}:
            continue
            
        appid = int(entry.get("appid", 0))
        if not appid:
            continue
            
        unsigned_appid = appid & 0xFFFFFFFF
        
        # Para cada tipo de arte (p, _hero, _logo, _icon)
        for _, (_, steam_suffix) in IMAGE_TYPES.items():
            found_files = []
            for ext in [".ico", ".png", ".jpg", ".jpeg"]:
                img_path = settings.grid_dir / f"{unsigned_appid}{steam_suffix}{ext}"
                if img_path.exists():
                    found_files.append(img_path)
            
            # Se encontrou mais de um arquivo para o mesmo sufixo, precisamos limpar
            if len(found_files) > 1:
                # Ordena por prioridade de extensao (ico > png > jpg)
                to_keep = found_files[0]
                for f in found_files[1:]:
                    try:
                        f.unlink()
                        removed_count += 1
                    except OSError:
                        pass
                
                # Se for o _icon, garante que o 'icon' no VDF aponte para o arquivo que sobreviveu
                if steam_suffix == "_icon" and entry.get("icon") != str(to_keep):
                    entry["icon"] = str(to_keep)
                    vdf_updated = True
            
            # Caso especial: Se houver apenas 1 arquivo mas o VDF estiver apontando errado (ex: .png vs .ico)
            elif len(found_files) == 1:
                to_keep = found_files[0]
                if steam_suffix == "_icon" and entry.get("icon") != str(to_keep):
                    entry["icon"] = str(to_keep)
                    vdf_updated = True

    if vdf_updated:
        _save_shortcuts(path, payload)
                    
    return removed_count


def repair_library(settings: Settings, progress_callback: callable | None = None) -> dict:
    """Executa todas as correcoes de caminho e limpeza sem adicionar novos jogos.
    Útil para quando o usuario moveu pastas ou mudou extensoes de imagem.
    """
    def sub_callback(phase: str, p_start: int, p_end: int):
        def cb(title: str, current: int, total: int):
            if progress_callback:
                # Mapeia o progresso da fase para o intervalo total [p_start, p_end]
                range_size = p_end - p_start
                percent = p_start + (current / total * range_size) if total > 0 else p_end
                progress_callback(title, int(percent), 100)
        return cb

    rebuilt_icons = rebuild_missing_icons(settings, progress_callback=sub_callback("rebuild", 0, 25))
    updated_paths = update_artwork_paths(settings, progress_callback=sub_callback("paths", 25, 50))
    cleaned_files = scan_and_fix_artworks(settings, progress_callback=sub_callback("cleanup", 50, 75))
    fixed_paths = validate_shortcut_paths(settings, progress_callback=sub_callback("validate", 75, 100))
    
    return {
        "rebuilt_icons": rebuilt_icons,
        "updated_paths": updated_paths,
        "cleaned_files": cleaned_files,
        "fixed_paths": fixed_paths
    }
