from __future__ import annotations

import os
import shutil
import sys
from dataclasses import dataclass, field
from pathlib import Path


def _unique_existing(paths: list[Path]) -> list[Path]:
    seen: set[str] = set()
    results: list[Path] = []
    for path in paths:
        try:
            resolved = str(path.resolve())
        except OSError:
            resolved = str(path)
        if resolved in seen or not path.exists():
            continue
        seen.add(resolved)
        results.append(path)
    return results


def _safe_glob(base: Path, pattern: str) -> list[Path]:
    try:
        return list(base.glob(pattern)) if base.exists() else []
    except OSError:
        return []


@dataclass(slots=True)
class DiscoveryResult:
    steam_roots: list[Path] = field(default_factory=list)
    steam_user_ids: list[str] = field(default_factory=list)
    legendary_bins: list[Path] = field(default_factory=list)
    epic_launcher_bins: list[Path] = field(default_factory=list)

    @property
    def preferred_steam_root(self) -> Path | None:
        return self.steam_roots[0] if self.steam_roots else None

    @property
    def preferred_steam_user_id(self) -> str | None:
        return self.steam_user_ids[0] if self.steam_user_ids else None

    @property
    def preferred_legendary_bin(self) -> Path | None:
        return self.legendary_bins[0] if self.legendary_bins else None

    @property
    def preferred_epic_launcher_bin(self) -> Path | None:
        return self.epic_launcher_bins[0] if self.epic_launcher_bins else None


def find_steam_roots() -> list[Path]:
    candidates: list[Path] = []

    env_value = os.getenv("STEAM_PATH")
    if env_value:
        candidates.append(Path(env_value).expanduser())

    if sys.platform == "win32":
        try:
            import winreg

            for hive, subkey in [
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Wow6432Node\Valve\Steam"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam"),
                (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Valve\Steam"),
            ]:
                try:
                    with winreg.OpenKey(hive, subkey) as key:
                        install_path, _ = winreg.QueryValueEx(key, "InstallPath")
                        if install_path:
                            candidates.append(Path(install_path))
                except FileNotFoundError:
                    continue
        except ImportError:
            pass

        candidates.extend(
            [
                Path(os.getenv("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Steam",
                Path(os.getenv("PROGRAMFILES", r"C:\Program Files")) / "Steam",
                Path.home() / "AppData" / "Local" / "Steam",
            ]
        )
    else:
        candidates.extend(
            [
                Path.home() / ".steam" / "steam",
                Path.home() / ".steam" / "root",
                Path.home() / ".local" / "share" / "Steam",
                Path.home() / ".var" / "app" / "com.valvesoftware.Steam" / ".steam" / "steam",
                Path.home() / ".var" / "app" / "com.valvesoftware.Steam" / ".steam" / "root",
                Path.home() / "Library" / "Application Support" / "Steam",
            ]
        )
    return _unique_existing(candidates)


def find_steam_user_ids(steam_root: Path | None = None) -> list[str]:
    roots = [steam_root] if steam_root else find_steam_roots()
    found: list[tuple[str, float]] = []
    for root in roots:
        userdata = root / "userdata"
        if not userdata.exists():
            continue
        try:
            for child in userdata.iterdir():
                if not child.is_dir() or not child.name.isdigit():
                    continue
                found.append((child.name, child.stat().st_mtime))
        except OSError:
            continue

    ordered = sorted(found, key=lambda item: item[1], reverse=True)
    seen: set[str] = set()
    result: list[str] = []
    for user_id, _ in ordered:
        if user_id in seen:
            continue
        seen.add(user_id)
        result.append(user_id)
    return result


def find_legendary_binaries() -> list[Path]:
    candidates: list[Path] = []

    configured = os.getenv("SEB_LEGENDARY_PATH")
    if configured:
        candidates.append(Path(configured))

    which_found = shutil.which("legendary")
    if which_found:
        candidates.append(Path(which_found))

    which_exe = shutil.which("legendary.exe")
    if which_exe:
        candidates.append(Path(which_exe))

    if sys.platform != "win32":
        candidates.extend(
            [
                Path.home() / ".local" / "bin" / "legendary",
                Path("/usr/bin/legendary"),
                Path("/usr/local/bin/legendary"),
            ]
        )

    package_bin = Path(__file__).resolve().parent / "bin" / "legendary.exe"
    candidates.append(package_bin)

    local_appdata = Path(os.getenv("LOCALAPPDATA", ""))
    appdata = Path(os.getenv("APPDATA", ""))
    search_paths = [
        local_appdata / "Programs" / "Python" / "Python313" / "Scripts",
        local_appdata / "Programs" / "Python" / "Python312" / "Scripts",
        local_appdata / "Programs" / "Python" / "Python311" / "Scripts",
        appdata / "Python" / "Python313" / "Scripts",
        appdata / "Python" / "Python312" / "Scripts",
        appdata / "Python" / "Python311" / "Scripts",
    ]
    for base in search_paths:
        candidates.append(base / "legendary.exe")

    local_packages = local_appdata / "Packages"
    for package_dir in _safe_glob(local_packages, "PythonSoftwareFoundation.Python*"):
        for py_dir in _safe_glob(package_dir / "LocalCache" / "local-packages", "Python*"):
            candidates.append(py_dir / "Scripts" / "legendary.exe")

    return _unique_existing(candidates)


def find_epic_launcher_binaries() -> list[Path]:
    candidates: list[Path] = []

    candidates.extend(
        [
            Path(os.getenv("PROGRAMFILES(X86)", r"C:\Program Files (x86)"))
            / "Epic Games"
            / "Launcher"
            / "Portal"
            / "Binaries"
            / "Win64"
            / "EpicGamesLauncher.exe",
            Path(os.getenv("PROGRAMFILES", r"C:\Program Files"))
            / "Epic Games"
            / "Launcher"
            / "Portal"
            / "Binaries"
            / "Win64"
            / "EpicGamesLauncher.exe",
            Path.home()
            / "AppData"
            / "Local"
            / "EpicGamesLauncher"
            / "Saved",
        ]
    )
    return _unique_existing(candidates)


def discover_environment() -> DiscoveryResult:
    steam_roots = find_steam_roots()
    preferred_root = steam_roots[0] if steam_roots else None
    return DiscoveryResult(
        steam_roots=steam_roots,
        steam_user_ids=find_steam_user_ids(preferred_root),
        legendary_bins=find_legendary_binaries(),
        epic_launcher_bins=find_epic_launcher_binaries(),
    )
