from __future__ import annotations

import threading
import tkinter as tk
import webbrowser
from tkinter import messagebox, ttk

from steam_epic_bridge.config import get_settings, load_config_file, save_config_file
from steam_epic_bridge.core import SyncEngine
from steam_epic_bridge.models import SyncResult
from steam_epic_bridge.scheduler import register_task, unregister_task
from steam_epic_bridge.steam_shortcuts import is_steam_running


class BridgeGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Steam Epic Bridge")
        self.root.geometry("660x920")
        self.root.minsize(620, 780)
        self.root.resizable(True, True)

        self.settings = get_settings()
        self.engine = SyncEngine(self.settings)

        self._setup_style()
        self._create_widgets()
        self._refresh_status()
        self.root.after(300, self._maybe_run_first_use)

    def _setup_style(self) -> None:
        style = ttk.Style()
        style.theme_use('clam')
        
        # Paleta HSL-Tailored: Dark Space e Neon Luminescente
        bg_color = "#0b0b0e"       # Fundo espacial profundo
        card_bg = "#12121a"        # Corpo de cards / labelframes
        text_fg = "#ffffff"        # Texto legível
        dim_gray = "#8a8a9e"       # Texto secundário
        neon_cyan = "#00f0ff"      # Cyan Brilhante para foco e destaques
        neon_purple = "#8a2be2"    # Purple realçado para ações principais
        dark_purple = "#5f14a3"    # Purple ativo / hover
        border_color = "#242430"   # Borda sutil de containers
        
        # Configura fundo da janela principal
        self.root.configure(background=bg_color)
        
        # Estilos Base
        style.configure(".", background=bg_color, foreground=text_fg, font=("Segoe UI", 10))
        style.configure("TFrame", background=bg_color)
        
        # Cards (LabelFrames)
        style.configure("TLabelframe", background=card_bg, bordercolor=border_color, borderwidth=1, relief="solid")
        style.configure("TLabelframe.Label", background=bg_color, foreground=neon_cyan, font=("Segoe UI", 10, "bold"))
        
        # Labels
        style.configure("TLabel", background=bg_color, foreground=text_fg)
        style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"), foreground=neon_cyan)
        style.configure("Status.TLabel", font=("Segoe UI", 10), background=card_bg, foreground=text_fg)
        
        # Cards Internos
        style.configure("Card.TFrame", background=card_bg)
        style.configure("Card.TLabel", background=card_bg, foreground=text_fg)
        style.configure("CardTitle.TLabel", background=card_bg, foreground=neon_cyan, font=("Segoe UI", 10, "bold"))
        style.configure("CardHelp.TLabel", background=card_bg, foreground=dim_gray, font=("Segoe UI", 8))
        
        # Botões - Premium e com Foco Neon
        style.configure("TButton", 
                        background=neon_purple, 
                        foreground=text_fg, 
                        borderwidth=1, 
                        bordercolor=neon_purple, 
                        padding=(10, 6), 
                        font=("Segoe UI", 10, "bold"), 
                        relief="flat")
        
        style.map("TButton",
                 background=[("active", dark_purple), ("focus", neon_cyan), ("disabled", "#1c1c24")],
                 foreground=[("focus", "#000000"), ("disabled", "#5a5a6a")],
                 bordercolor=[("focus", neon_cyan), ("active", neon_cyan)])
                 
        # Caixa de Entrada (Entry) - Estilo Dark com borda Neon no Foco
        style.configure("TEntry", 
                        fieldbackground="#07070a", 
                        foreground=text_fg, 
                        bordercolor=border_color, 
                        insertcolor=text_fg,
                        borderwidth=2, 
                        padding=5)
        style.map("TEntry", 
                 bordercolor=[("focus", neon_cyan)],
                 fieldbackground=[("focus", "#0b0b0e")])
                 
        # Checkbuttons - Acessíveis com destaque de foco
        style.configure("TCheckbutton", background=card_bg, foreground=text_fg, padding=4)
        style.map("TCheckbutton", 
                 background=[("active", card_bg), ("focus", card_bg)],
                 foreground=[("focus", neon_cyan)])
                 
        # Combobox
        style.configure("TCombobox", 
                        fieldbackground="#07070a", 
                        background=card_bg,
                        foreground=text_fg, 
                        bordercolor=border_color, 
                        arrowcolor=text_fg,
                        padding=5)
        style.map("TCombobox", 
                 bordercolor=[("focus", neon_cyan)])
                 
        # Barra de Progresso (Progressbar)
        style.configure("Horizontal.TProgressbar", 
                       background=neon_cyan, 
                       troughcolor="#07070a", 
                       bordercolor=border_color, 
                       thickness=8)
                       
        # Barra de Rolagem (Scrollbar)
        style.configure("Vertical.TScrollbar", 
                       background="#12121a", 
                       troughcolor=bg_color, 
                       bordercolor=border_color, 
                       arrowcolor=text_fg, 
                       gripcount=0)
        style.map("Vertical.TScrollbar", 
                 background=[("active", neon_cyan)])

    def _create_widgets(self) -> None:
        # Fundo do Container Principal
        container = ttk.Frame(self.root)
        container.pack(fill=tk.BOTH, expand=True)
 
        self.canvas = tk.Canvas(container, highlightthickness=0, background="#0b0b0e")
        scrollbar = ttk.Scrollbar(container, orient=tk.VERTICAL, command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=scrollbar.set)
 
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
 
        main_frame = ttk.Frame(self.canvas, padding="20")
        self.canvas_window = self.canvas.create_window((0, 0), window=main_frame, anchor="nw")
 
        main_frame.bind(
            "<Configure>",
            lambda event: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda event: self.canvas.itemconfigure(self.canvas_window, width=event.width),
        )
        self.canvas.bind("<Enter>", self._bind_mousewheel)
        self.canvas.bind("<Leave>", self._unbind_mousewheel)
        
        # ==========================================
        # ROLAGEM TOUCH (DRAG-SCROLL INTELIGENTE)
        # ==========================================
        self.canvas.bind("<Button-1>", self._on_drag_start)
        self.canvas.bind("<B1-Motion>", self._on_drag_motion)
        main_frame.bind("<Button-1>", self._on_drag_start)
        main_frame.bind("<B1-Motion>", self._on_drag_motion)
 
        # Cabeçalho Principal
        ttk.Label(main_frame, text="Steam Epic Bridge", style="Title.TLabel").pack(pady=(0, 5))
        ttk.Label(
            main_frame,
            text="Sincronize sua biblioteca Epic no Steam com mais seguranca.",
            foreground="#8a8a9e",
        ).pack(pady=(0, 20))
 
        # 1. CARD: STATUS DO SISTEMA
        status_frame = ttk.LabelFrame(main_frame, text=" Status do Sistema ", padding="12")
        status_frame.pack(fill=tk.X, pady=(0, 15))
 
        self.status_var = tk.StringVar(value="Carregando status...")
        self.status_label = ttk.Label(
            status_frame,
            textvariable=self.status_var,
            style="Status.TLabel",
            wraplength=550,
            justify=tk.LEFT,
        )
        self.status_label.pack(fill=tk.X, side=tk.TOP)
 
        self.login_btn = ttk.Button(status_frame, text="Conectar Conta Epic", command=self._run_login)
        self.login_btn.pack(pady=(12, 0))
 
        # 2. CARD: ARTWORKS E STEAMGRIDDB
        config_frame = ttk.LabelFrame(main_frame, text=" SteamGridDB (Capas dos Jogos) ", padding="12")
        config_frame.pack(fill=tk.X, pady=(0, 15))
 
        ttk.Label(
            config_frame,
            text=(
                "Baixa capas automaticamente para seus jogos ficarem bonitos no Steam.\n"
                "Gratuito: basta criar uma conta e gerar a chave."
            ),
            style="CardHelp.TLabel",
            justify=tk.LEFT,
        ).pack(fill=tk.X, pady=(0, 10))
 
        key_row = ttk.Frame(config_frame, style="Card.TFrame")
        key_row.pack(fill=tk.X)
 
        ttk.Label(key_row, text="API Key:", style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 5))
        self.api_key_var = tk.StringVar(value=self.settings.steamgriddb_api_key or "")
        self.api_key_entry = ttk.Entry(key_row, textvariable=self.api_key_var, show="*")
        self.api_key_entry.pack(
            side=tk.LEFT,
            fill=tk.X,
            expand=True,
            padx=(0, 5),
        )
        self.save_api_key_btn = ttk.Button(key_row, text="Salvar", command=self._save_api_key)
        self.save_api_key_btn.pack(side=tk.LEFT)
 
        self.open_db_btn = ttk.Button(
            config_frame,
            text="Abrir SteamGridDB (pegar chave gratis)",
            command=lambda: webbrowser.open("https://www.steamgriddb.com/profile/preferences/api"),
        )
        self.open_db_btn.pack(fill=tk.X, pady=(10, 0))
 
        beautifier_frame = ttk.Frame(config_frame, style="Card.TFrame")
        beautifier_frame.pack(fill=tk.X, pady=(12, 0))
        
        self.prefer_animated_var = tk.BooleanVar(value=self.settings.prefer_animated)
        self.prefer_animated_chk = ttk.Checkbutton(
            beautifier_frame, 
            text="Preferir Capas Animadas (GIF/APNG)", 
            variable=self.prefer_animated_var
        )
        self.prefer_animated_chk.pack(side=tk.LEFT)
        
        ttk.Label(beautifier_frame, text="Estilo:", style="Card.TLabel").pack(side=tk.LEFT, padx=(15, 5))
        self.artwork_style_var = tk.StringVar(value=self.settings.artwork_style)
        self.style_combo = ttk.Combobox(
            beautifier_frame, 
            textvariable=self.artwork_style_var, 
            values=["any", "alternate", "blurred", "white_logo", "material", "no_logo"],
            width=10,
            state="readonly"
        )
        self.style_combo.pack(side=tk.LEFT)
 
        # 3. CARD: OPÇÕES DO SINCRO
        options_frame = ttk.LabelFrame(main_frame, text=" Opcoes ", padding="12")
        options_frame.pack(fill=tk.X, pady=(0, 15))
 
        self.dry_run_var = tk.BooleanVar(value=False)
        self.installed_only_var = tk.BooleanVar(value=False)
        
        self.dry_run_chk = ttk.Checkbutton(
            options_frame,
            text="Executar primeiro em dry-run (apenas teste)",
            variable=self.dry_run_var,
        )
        self.dry_run_chk.pack(anchor=tk.W, pady=(0, 4))
        
        self.installed_only_chk = ttk.Checkbutton(
            options_frame,
            text="Sincronizar apenas jogos instalados",
            variable=self.installed_only_var,
        )
        self.installed_only_chk.pack(anchor=tk.W)
 
        # Agendamento
        schedule_frame = ttk.Frame(options_frame, style="Card.TFrame")
        schedule_frame.pack(fill=tk.X, pady=(12, 0))
        ttk.Label(schedule_frame, text="Automacao:", style="Card.TLabel").pack(side=tk.LEFT, padx=(0, 5))
        
        self.schedule_btn = ttk.Button(
            schedule_frame,
            text="Agendar (04:00)",
            command=lambda: self._run_schedule(True),
        )
        self.schedule_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        self.remove_schedule_btn = ttk.Button(
            schedule_frame,
            text="Remover Agendamento",
            command=lambda: self._run_schedule(False),
        )
        self.remove_schedule_btn.pack(side=tk.LEFT)
 
        # 4. CARD: OPERAÇÕES PRINCIPAIS (BOTOES MAIORES)
        primary_btn_frame = ttk.Frame(main_frame)
        primary_btn_frame.pack(fill=tk.X, pady=(10, 8))
 
        self.sync_btn = ttk.Button(primary_btn_frame, text="Sincronizar Tudo", command=self._run_sync)
        self.sync_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
 
        self.doctor_btn = ttk.Button(primary_btn_frame, text="Diagnosticar", command=self._run_doctor)
        self.doctor_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))
 
        self.repair_btn = ttk.Button(primary_btn_frame, text="Reparar Atalhos", command=self._run_repair)
        self.repair_btn.pack(side=tk.LEFT, fill=tk.X, expand=True)
 
        self.first_use_btn = ttk.Button(main_frame, text="Assistente de Primeiro Uso", command=self._run_first_use)
        self.first_use_btn.pack(fill=tk.X, pady=(0, 12))
 
        # 5. CARD: MANUTENÇÃO SECUNDÁRIA
        secondary_btn_frame = ttk.Frame(main_frame)
        secondary_btn_frame.pack(fill=tk.X, pady=(0, 12))
 
        self.clean_btn = ttk.Button(secondary_btn_frame, text="Limpar Atalhos", command=self._run_clean)
        self.clean_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
 
        self.restore_btn = ttk.Button(secondary_btn_frame, text="Restaurar Backup", command=self._run_restore)
        self.restore_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
 
        self.clear_art_btn = ttk.Button(secondary_btn_frame, text="Limpar Cache Imagens", command=self._run_clear_art)
        self.clear_art_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 4))
 
        self.refresh_btn = ttk.Button(secondary_btn_frame, text="Atualizar Status", command=self._refresh_status)
        self.refresh_btn.pack(side=tk.LEFT, fill=tk.X, expand=True)
 
        # 6. CARD: CORREÇÕES ESPECIAIS
        special_frame = ttk.LabelFrame(main_frame, text=" Melhorias de Arte ", padding="12")
        special_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(
            special_frame,
            text="Corrige jogos antigos do Steam que tem capas esticadas ou faltando o formato vertical moderno.",
            style="CardHelp.TLabel",
            justify=tk.LEFT,
            wraplength=550,
        ).pack(fill=tk.X, pady=(0, 10))
 
        self.fix_ratios_btn = ttk.Button(special_frame, text="Consertar Proporções (Steam Antigo)", command=self._run_fix_ratios)
        self.fix_ratios_btn.pack(fill=tk.X)
 
        # 7. CARD: RESTAURAÇÃO TOTAL (DANGER CARD)
        danger_frame = ttk.LabelFrame(main_frame, text=" Restauracao Completa ", padding="12")
        danger_frame.pack(fill=tk.X, pady=(0, 15))
        ttk.Label(
            danger_frame,
            text=(
                "Use apenas se quiser desfazer tudo: restaura o ultimo backup do Steam "
                "e limpa imagens/cache do app."
            ),
            style="CardHelp.TLabel",
            justify=tk.LEFT,
            wraplength=550,
        ).pack(fill=tk.X, pady=(0, 10))
        self.reset_btn = ttk.Button(
            danger_frame,
            text="Resetar Tudo",
            command=self._run_reset_all,
        )
        self.reset_btn.pack(fill=tk.X)
 
        # Progresso e Logs
        self.progress_var = tk.DoubleVar()
        ttk.Progressbar(main_frame, variable=self.progress_var, maximum=100).pack(fill=tk.X, pady=(15, 0))
 
        self.log_var = tk.StringVar(value="Pronto")
        ttk.Label(
            main_frame,
            textvariable=self.log_var,
            font=("Segoe UI", 9, "italic"),
            foreground="#8a8a9e",
        ).pack(pady=(8, 0))
        
        # ==========================================
        # GRID DE FOCO (CONTROLES / TECLADO / TV)
        # ==========================================
        self.focus_grid = [
            [self.login_btn],
            [self.api_key_entry, self.save_api_key_btn],
            [self.open_db_btn],
            [self.prefer_animated_chk, self.style_combo],
            [self.dry_run_chk],
            [self.installed_only_chk],
            [self.schedule_btn, self.remove_schedule_btn],
            [self.sync_btn, self.doctor_btn, self.repair_btn],
            [self.first_use_btn],
            [self.clean_btn, self.restore_btn, self.clear_art_btn, self.refresh_btn],
            [self.fix_ratios_btn],
            [self.reset_btn]
        ]
        
        # Bind de navegação direcional lógica
        self.root.bind("<Up>", lambda event: self._move_focus(-1, 0))
        self.root.bind("<Down>", lambda event: self._move_focus(1, 0))
        self.root.bind("<Left>", lambda event: self._move_focus(0, -1))
        self.root.bind("<Right>", lambda event: self._move_focus(0, 1))
        
        # Ativação fácil de botões com Enter globais
        self.root.bind_class("TButton", "<Return>", lambda event: event.widget.invoke())
        
        # Aplica a vinculação recursiva de toque inteligente após o desenho
        self.root.after(150, lambda: self._bind_touch_scroll(main_frame))

    def _on_drag_start(self, event) -> None:
        self.canvas.scan_mark(event.x_root, event.y_root)

    def _on_drag_motion(self, event) -> None:
        self.canvas.scan_dragto(event.x_root, event.y_root, gain=1)

    def _bind_touch_scroll(self, widget) -> None:
        # Vincula apenas para componentes que não absorvem interações de texto/botão
        widget_class = widget.winfo_class()
        if widget_class not in ("Button", "TButton", "Entry", "TEntry", "Combobox", "TCombobox", "Checkbutton", "TCheckbutton"):
            widget.bind("<Button-1>", self._on_drag_start, add="+")
            widget.bind("<B1-Motion>", self._on_drag_motion, add="+")
            
        for child in widget.winfo_children():
            self._bind_touch_scroll(child)

    def _move_focus(self, dr: int, dc: int) -> None:
        current = self.root.focus_get()
        if not current:
            self._focus_widget(0, 0)
            return
            
        found = False
        r, c = 0, 0
        for row_idx, row in enumerate(self.focus_grid):
            if current in row:
                r = row_idx
                c = row.index(current)
                found = True
                break
                
        if not found:
            self._focus_widget(0, 0)
            return
            
        max_attempts = 50
        attempts = 0
        
        while attempts < max_attempts:
            attempts += 1
            if dr != 0:
                r = (r + dr) % len(self.focus_grid)
                c = min(c, len(self.focus_grid[r]) - 1)
            elif dc != 0:
                c += dc
                if c < 0:
                    r = (r - 1) % len(self.focus_grid)
                    c = len(self.focus_grid[r]) - 1
                elif c >= len(self.focus_grid[r]):
                    r = (r + 1) % len(self.focus_grid)
                    c = 0
                    
            target = self.focus_grid[r][c]
            try:
                # Pula elementos desativados
                state = target.state()
                if "disabled" in state:
                    continue
            except Exception:
                try:
                    if str(target.cget("state")) == "disabled":
                        continue
                except Exception:
                    pass
            
            target.focus_set()
            self._scroll_to_widget(target)
            break

    def _focus_widget(self, r: int, c: int) -> None:
        try:
            target = self.focus_grid[r][c]
            target.focus_set()
            self._scroll_to_widget(target)
        except Exception:
            pass

    def _scroll_to_widget(self, widget) -> None:
        self.root.update_idletasks()
        try:
            widget_y = widget.winfo_y()
            widget_h = widget.winfo_height()
            canvas_h = self.canvas.winfo_height()
            
            y1, y2 = self.canvas.yview()
            scroll_region = self.canvas.bbox("all")
            if not scroll_region:
                return
            total_h = scroll_region[3] - scroll_region[1]
            
            if total_h <= canvas_h:
                return
                
            widget_top_ratio = widget_y / total_h
            widget_bottom_ratio = (widget_y + widget_h) / total_h
            
            if widget_top_ratio < y1:
                self.canvas.yview_moveto(max(0.0, widget_top_ratio - 0.05))
            elif widget_bottom_ratio > y2:
                self.canvas.yview_moveto(min(1.0, widget_bottom_ratio - (canvas_h / total_h) + 0.05))
        except Exception:
            pass

    def _bind_mousewheel(self, _event=None) -> None:
        self.root.bind_all("<MouseWheel>", self._on_mousewheel)

    def _unbind_mousewheel(self, _event=None) -> None:
        self.root.unbind_all("<MouseWheel>")

    def _on_mousewheel(self, event) -> None:
        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _set_busy(self, busy: bool) -> None:
        state = ["disabled"] if busy else ["!disabled"]
        for widget in (
            self.sync_btn,
            self.doctor_btn,
            self.clean_btn,
            self.restore_btn,
            self.clear_art_btn,
            self.login_btn,
            self.repair_btn,
            self.reset_btn,
            self.fix_ratios_btn,
            self.api_key_entry,
        ):
            widget.state(state)


    def _refresh_status(self) -> None:
        self.status_var.set("Atualizando status...")

        def worker() -> None:
            self.settings = get_settings()
            self.engine = SyncEngine(self.settings)
            try:
                data = self.engine.get_status()
                lines = [
                    f"- Steam ID: {data.get('steam_user_id', 'Nao detectado')}",
                    f"- Jogos na Epic: {data.get('epic_games', 'Indisponivel')}",
                    f"- Atalhos no Steam: {data.get('epic_shortcuts', 0)}",
                    f"- Artwork automatica: {'sim' if data.get('artwork_enabled') else 'nao'}",
                ]
                if data.get("epic_games") == "Indisponivel":
                    lines.append("- Epic: conecte sua conta usando o botao abaixo")
                result_text = "\n".join(lines)
                self.root.after(0, lambda: self.status_var.set(result_text))
            except Exception:
                self.root.after(
                    0,
                    lambda: self.status_var.set(
                        "Steam detectado, mas Epic indisponivel. Use 'Conectar Conta Epic'."
                    ),
                )

        threading.Thread(target=worker, daemon=True).start()

    def _save_api_key(self) -> None:
        key = self.api_key_var.get().strip()
        config = load_config_file()
        config["steamgriddb_api_key"] = key
        config["prefer_animated"] = bool(self.prefer_animated_var.get())
        config["artwork_style"] = self.artwork_style_var.get()
        save_config_file(config)
        self.settings = get_settings()

        self.engine = SyncEngine(self.settings)
        self.log_var.set("Chave SteamGridDB salva.")
        messagebox.showinfo("Sucesso", "Chave de API salva com sucesso.")
        self._refresh_status()


    def _run_doctor(self) -> None:
        self.settings = get_settings()
        self.engine = SyncEngine(self.settings)
        try:
            data = self.engine.doctor()
        except Exception as exc:
            self._on_error(exc)
            return

        lines = [
            f"Steam instalado: {'OK' if data['steam_root_exists'] else 'Falhou'}",
            f"Steam user id: {data['steam_user_id'] or 'Nao detectado'}",
            f"Config do Steam: {'OK' if data['steam_config_ready'] else 'Nao encontrada'}",
            f"Backup disponivel: {'Sim' if data['backup_available'] else 'Nao'}",
            f"Legendary: {data['legendary_bin']}",
            f"Epic autenticada: {'OK' if data['epic_authenticated'] else data['epic_auth_error'] or 'Falhou'}",
            f"Biblioteca Epic: {data['epic_games'] if data['epic_games'] is not None else data['epic_library_error'] or 'Indisponivel'}",
            f"SteamGridDB: {'Configurada' if data['artwork_enabled'] else 'Sem chave'}",
            "",
            f"Steam roots encontrados: {len(data['discovered_steam_roots'])}",
            f"Steam IDs encontrados: {len(data['discovered_steam_user_ids'])}",
            f"Legendary encontrados: {len(data['discovered_legendary_bins'])}",
            f"Epic Launchers encontrados: {len(data['discovered_epic_launchers'])}",
        ]
        self.log_var.set("Diagnostico concluido.")
        messagebox.showinfo("Diagnostico", "\n".join(lines))

    def _maybe_run_first_use(self) -> None:
        config = load_config_file()
        if config.get("first_run_completed"):
            return
        self._run_first_use()

    def _run_first_use(self) -> None:
        self.settings = get_settings()
        self.engine = SyncEngine(self.settings)
        data = self.engine.doctor()

        intro = [
            "Bem-vindo ao Steam Epic Bridge.",
            "",
            f"Steam instalado: {'OK' if data['steam_root_exists'] else 'Falhou'}",
            f"Steam user id: {data['steam_user_id'] or 'Nao detectado'}",
            f"Legendary encontrado: {'Sim' if data['discovered_legendary_bins'] else 'Nao'}",
            f"Epic autenticada: {'Sim' if data['epic_authenticated'] else 'Nao'}",
            f"SteamGridDB configurada: {'Sim' if data['artwork_enabled'] else 'Nao'}",
            "",
            "O assistente pode te guiar no primeiro sync.",
        ]
        messagebox.showinfo("Primeiro Uso", "\n".join(intro))

        if not data["epic_authenticated"]:
            if messagebox.askyesno("Primeiro Uso", "Sua conta Epic ainda nao esta conectada. Deseja conectar agora?"):
                self._run_login()
                return

        if not data["artwork_enabled"]:
            if messagebox.askyesno("Primeiro Uso", "Deseja configurar agora a chave da SteamGridDB para baixar capas?"):
                webbrowser.open("https://www.steamgriddb.com/profile/preferences/api")

        if messagebox.askyesno("Primeiro Uso", "Deseja fazer um dry-run agora para testar o ambiente sem alterar o Steam?"):
            self.dry_run_var.set(True)
            self._run_sync()

        config = load_config_file()
        config["first_run_completed"] = True
        save_config_file(config)

    def _run_repair(self) -> None:
        if is_steam_running():
            messagebox.showwarning("Steam Aberto", "Feche o Steam completamente antes de reparar.")
            return

        self.settings = get_settings()
        self.engine = SyncEngine(self.settings)
        self._set_busy(True)
        self.progress_var.set(0)
        self.log_var.set("Reparando caminhos e limpando duplicatas...")

        def progress_cb(title: str, current: int, total: int) -> None:
            percent = int((current / total) * 100) if total > 0 else 0
            self.root.after(0, lambda: self.log_var.set(f"{title} ({current}/{total})"))
            self.root.after(0, lambda: self.progress_var.set(percent))

        def target() -> None:
            try:
                result = self.engine.repair(progress_callback=progress_cb)
                self.root.after(0, lambda result=result: self._on_repair_complete(result))
            except Exception as exc:
                self.root.after(0, lambda exc=exc: self._on_error(exc))

        threading.Thread(target=target, daemon=True).start()

    def _on_repair_complete(self, result: dict) -> None:
        self._set_busy(False)
        self.progress_var.set(100)
        self.log_var.set("Reparo concluido.")
        self._refresh_status()
        messagebox.showinfo(
            "Reparar Atalhos",
            "Reparo concluido!\n\n"
            f"- Icones reconstruidos: {result['rebuilt_icons']}\n"
            f"- Icones atualizados no VDF: {result['updated_paths']}\n"
            f"- Caminhos de EXE/Pasta corrigidos: {result.get('fixed_paths', 0)}\n"
            f"- Arquivos duplicados removidos: {result['cleaned_files']}",
        )

    def _run_sync(self) -> None:
        if is_steam_running():
            messagebox.showwarning("Steam Aberto", "Feche o Steam completamente antes de sincronizar.")
            return

        self.settings = get_settings()
        self.engine = SyncEngine(self.settings)
        self._set_busy(True)
        self.progress_var.set(0)
        self.log_var.set("Iniciando sincronizacao...")

        def target() -> None:
            try:
                def progress_cb(title: str, current: int, total: int) -> None:
                    percent = int((current / total) * 100) if total > 0 else 0
                    self.root.after(0, lambda: self.log_var.set(f"{title} ({current}/{total})"))
                    self.root.after(0, lambda: self.progress_var.set(percent))

                result = self.engine.sync(
                    installed_only=self.installed_only_var.get(),
                    dry_run=self.dry_run_var.get(),
                    progress_callback=progress_cb,
                )
                dry_run = self.dry_run_var.get()
                self.root.after(0, lambda result=result, dry_run=dry_run: self._on_sync_complete(result, dry_run))
            except Exception as exc:
                self.root.after(0, lambda exc=exc: self._on_error(exc))

        threading.Thread(target=target, daemon=True).start()

    def _on_sync_complete(self, result: SyncResult, dry_run: bool) -> None:
        self._set_busy(False)
        self.progress_var.set(100)
        self._refresh_status()

        if dry_run:
            self.log_var.set("Dry-run concluido.")
            messagebox.showinfo(
                "Dry-run",
                f"Novos atalhos previstos: {result.planned}\nJa existentes: {result.skipped}",
            )
            return

        self.log_var.set("Sincronizacao concluida.")
        msg = f"Sincronizacao concluida.\n\nCriados: {result.created}\nJa existiam: {result.skipped}"
        if result.artwork_downloaded:
            msg += f"\nCapas baixadas: {result.artwork_downloaded}"
        if result.backup_path:
            msg += f"\nBackup: {result.backup_path}"
        messagebox.showinfo("Sucesso", msg)

    def _run_clean(self) -> None:
        if is_steam_running():
            messagebox.showwarning("Steam Aberto", "Feche o Steam completamente antes de limpar.")
            return

        if not messagebox.askyesno("Confirmar", "Deseja remover todos os atalhos da Epic do Steam?"):
            return

        try:
            result = self.engine.clean()
            self.log_var.set("Atalhos removidos.")
            self._refresh_status()
            messagebox.showinfo("Sucesso", f"{result.removed} atalhos removidos.")
        except Exception as exc:
            self._on_error(exc)

    def _run_clear_art(self) -> None:
        if not messagebox.askyesno(
            "Confirmar",
            "Deseja limpar apenas o cache de imagens?\n\n"
            "Os atalhos continuarao no Steam, mas as capas e icones serao deletados.",
        ):
            return

        try:
            removed = self.engine.clear_art()
            self.log_var.set(f"Cache limpo: {removed} arquivos deletados.")
            messagebox.showinfo("Sucesso", f"Foram removidos {removed} arquivos de imagem do cache.")
        except Exception as exc:
            self._on_error(exc)

    def _run_restore(self) -> None:
        if is_steam_running():
            messagebox.showwarning("Steam Aberto", "Feche o Steam completamente antes de restaurar o backup.")
            return

        if not messagebox.askyesno("Confirmar", "Deseja restaurar o ultimo backup do shortcuts.vdf?"):
            return

        try:
            result = self.engine.restore()
            self.log_var.set("Backup restaurado.")
            self._refresh_status()
            messagebox.showinfo("Sucesso", f"Backup restaurado:\n{result.backup_path}")
        except Exception as exc:
            self._on_error(exc)

    def _run_reset_all(self) -> None:
        if is_steam_running():
            messagebox.showwarning("Steam Aberto", "Feche o Steam completamente antes de resetar tudo.")
            return

        self.settings = get_settings()
        self.engine = SyncEngine(self.settings)

        if not messagebox.askyesno(
            "Resetar Tudo",
            "Isso vai tentar deixar o Steam como antes do app:\n\n"
            "- restaurar o ultimo backup do shortcuts.vdf\n"
            "- ou remover os atalhos Epic se nao houver backup\n"
            "- apagar imagens baixadas\n"
            "- limpar o cache interno do app\n\n"
            "Deseja continuar?",
        ):
            return

        try:
            result = self.engine.reset_all()
            self._refresh_status()
            self.log_var.set("Reset completo concluido.")
            if result.restored_backup and result.backup_path:
                message = (
                    "Reset concluido.\n\n"
                    f"- Backup restaurado: {result.backup_path}\n"
                    f"- Imagens removidas: {result.removed_artwork}\n"
                    f"- Itens de cache removidos: {result.cleared_cache}"
                )
            else:
                message = (
                    "Reset concluido.\n\n"
                    f"- Atalhos Epic removidos: {result.removed_shortcuts}\n"
                    f"- Imagens removidas: {result.removed_artwork}\n"
                    f"- Itens de cache removidos: {result.cleared_cache}"
                )
            messagebox.showinfo("Resetar Tudo", message)
        except Exception as exc:
            self._on_error(exc)

    def _run_schedule(self, enable: bool) -> None:
        try:
            success, msg = register_task() if enable else unregister_task()
            if success:
                messagebox.showinfo("Sucesso", msg)
                self.log_var.set("Agendamento configurado." if enable else "Agendamento removido.")
            else:
                messagebox.showerror("Erro de Agendamento", msg)
                self.log_var.set("Erro no agendamento.")
        except Exception as exc:
            self._on_error(exc)

    def _run_login(self) -> None:
        EpicLoginDialog(self.root, self.settings, self._on_login_success)

    def _run_fix_ratios(self) -> None:
        if not self.settings.steamgriddb_api_key:
            messagebox.showwarning("API Key Faltando", "Voce precisa configurar a SteamGridDB API Key primeiro.")
            return

        if not messagebox.askyesno(
            "Consertar Proporções",
            "O app vai analisar sua pasta grid e tentar baixar capas verticais modernas "
            "para todos os jogos (Steam e Epic) que estiverem faltando ou com formato antigo.\n\n"
            "Deseja continuar?"
        ):
            return

        self._set_busy(True)
        self.progress_var.set(0)
        self.log_var.set("Analisando biblioteca Steam...")

        def progress_cb(title: str, current: int, total: int) -> None:
            percent = int((current / total) * 100) if total > 0 else 0
            self.root.after(0, lambda: self.log_var.set(f"{title} ({current}/{total})"))
            self.root.after(0, lambda: self.progress_var.set(percent))

        def target() -> None:
            try:
                fixed_count = self.engine.fix_steam_artworks(progress_callback=progress_cb)
                self.root.after(0, lambda count=fixed_count: self._on_fix_ratios_complete(count))
            except Exception as exc:
                self.root.after(0, lambda exc=exc: self._on_error(exc))

        threading.Thread(target=target, daemon=True).start()

    def _on_fix_ratios_complete(self, count: int) -> None:
        self._set_busy(False)
        self.progress_var.set(100)
        self.log_var.set(f"Correção concluida: {count} artes atualizadas.")
        messagebox.showinfo("Sucesso", f"Processo concluido!\n\nForam corrigidas/baixadas {count} novas artes verticais.")

    def _on_login_success(self) -> None:
        self._set_busy(False)
        self.log_var.set("Conta Epic conectada.")
        self._refresh_status()
        messagebox.showinfo("Sucesso", "Conta Epic conectada com sucesso.")

    def _on_error(self, exc: Exception) -> None:
        self._set_busy(False)
        self.progress_var.set(0)
        self.log_var.set("Erro na operacao.")
        messagebox.showerror("Erro", str(exc))


class EpicLoginDialog(tk.Toplevel):
    def __init__(self, parent, settings, on_success_callback):
        super().__init__(parent)
        self.settings = settings
        self.on_success_callback = on_success_callback
        
        self.title("Conectar Conta Epic Games")
        self.geometry("500x340")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()
        
        # Centralizar na tela em relação ao pai
        self.geometry(f"+{parent.winfo_x() + 70}+{parent.winfo_y() + 100}")
        self.configure(background="#0b0b0e")
        
        self._create_widgets()
        
    def _create_widgets(self):
        frame = ttk.Frame(self, padding="20")
        frame.pack(fill=tk.BOTH, expand=True)
        
        ttk.Label(
            frame, 
            text="Vincular Conta Epic Games", 
            font=("Segoe UI", 12, "bold")
        ).pack(pady=(0, 10))
        
        instructions = (
            "Para conectar sua conta, siga estes passos simples:\n\n"
            "1. Clique no botão abaixo para abrir a página de login da Epic.\n"
            "2. Faça o login na sua conta da Epic Games.\n"
            "3. Você verá uma página com um texto como: '{\"sid\": \"...\"}'.\n"
            "4. Copie todo o conteúdo dessa página e cole no campo abaixo."
        )
        
        ttk.Label(
            frame, 
            text=instructions, 
            font=("Segoe UI", 9), 
            justify=tk.LEFT,
            wraplength=460
        ).pack(pady=(0, 15), fill=tk.X)
        
        btn_open = ttk.Button(
            frame, 
            text="1. Abrir Página de Login da Epic", 
            command=self._open_browser
        )
        btn_open.pack(fill=tk.X, pady=(0, 15))
        
        entry_frame = ttk.Frame(frame)
        entry_frame.pack(fill=tk.X, pady=(0, 15))
        
        ttk.Label(entry_frame, text="Cole o Código (SID):", font=("Segoe UI", 9, "bold")).pack(anchor=tk.W)
        self.sid_var = tk.StringVar()
        self.sid_entry = ttk.Entry(entry_frame, textvariable=self.sid_var)
        self.sid_entry.pack(fill=tk.X, pady=(2, 0))
        self.sid_entry.focus()
        
        btn_submit = ttk.Button(
            frame, 
            text="2. Confirmar e Autenticar", 
            command=self._authenticate
        )
        btn_submit.pack(fill=tk.X)
        
    def _open_browser(self):
        webbrowser.open("https://www.epicgames.com/id/login?redirectUrl=https%3A%2F%2Fwww.epicgames.com%2Fid%2Fapi%2Fredirect%3FclientId%3D34a2df3f1e3e449fb3c17e743858f7a9%26responseType%3Dcode")
        
    def _authenticate(self):
        sid_raw = self.sid_var.get().strip()
        if not sid_raw:
            messagebox.showwarning("Aviso", "Por favor, cole o código (SID) recebido.")
            return
            
        # Tenta parsear caso o usuário cole o JSON inteiro '{"sid": "..."}'
        sid = sid_raw
        if '"sid"' in sid_raw:
            try:
                import re
                match = re.search(r'"sid"\s*:\s*"([^"]+)"', sid_raw)
                if match:
                    sid = match.group(1)
            except Exception:
                pass
                
        # Remove possíveis aspas extras
        sid = sid.strip('"{} \t\n\r')
        
        # Desabilitar botão para evitar cliques duplos
        self.title("Autenticando...")
        
        try:
            from steam_epic_bridge.epic_auth import login
            login(self.settings, sid)
            self.destroy()
            self.on_success_callback()
        except Exception as e:
            self.title("Conectar Conta Epic Games")
            messagebox.showerror("Erro de Autenticação", f"Falha ao conectar: {str(e)}")


def run_gui() -> None:
    root = tk.Tk()
    BridgeGUI(root)
    root.mainloop()
