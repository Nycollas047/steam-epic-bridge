from __future__ import annotations

import logging

import click
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn
from rich.table import Table

from steam_epic_bridge.config import Settings, get_settings, load_config_file, save_config_file
from steam_epic_bridge.epic_auth import EpicAuthError
from steam_epic_bridge.epic_library import EpicLibraryError
from steam_epic_bridge.gui import run_gui
from steam_epic_bridge.scheduler import register_task, unregister_task
from steam_epic_bridge.steam_shortcuts import SteamShortcutsError, is_steam_running
from steam_epic_bridge.sync import clear_art, clean, doctor, get_status, repair, reset_all, restore, sync_library


console = Console()


def _configure_logging(settings: Settings) -> None:
    level = logging.DEBUG if settings.debug else logging.INFO
    handlers: list[logging.Handler] = [logging.StreamHandler()]

    try:
        settings.log_path.parent.mkdir(parents=True, exist_ok=True)
        handlers.append(logging.FileHandler(settings.log_path, encoding="utf-8"))
    except Exception:
        pass

    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        handlers=handlers,
    )


@click.group()
def cli() -> None:
    """Steam Epic Bridge CLI."""


@cli.command()
def setup() -> None:
    """Configura a chave da SteamGridDB para baixar artes automaticamente."""
    console.print()
    console.print(
        Panel(
            "[bold cyan]Configuracao do Steam Epic Bridge[/bold cyan]\n\n"
            "Para que as capas aparecam na biblioteca do Steam, voce precisa\n"
            "de uma chave de API gratuita do [link=https://www.steamgriddb.com]SteamGridDB[/link].\n\n"
            "[bold]Como obter:[/bold]\n"
            "  1. Acesse https://www.steamgriddb.com\n"
            "  2. Crie uma conta gratuita\n"
            "  3. Va em Preferences > API e gere sua chave",
            title="Configuracao de Capas",
            border_style="cyan",
        )
    )
    console.print()

    current = load_config_file()
    current_key = current.get("steamgriddb_api_key", "")
    if current_key:
        console.print(f"[dim]Chave atual: {current_key[:8]}{'*' * max(len(current_key) - 8, 0)}[/dim]")

    prompt = (
        "Cole sua chave de API do SteamGridDB (Enter para manter atual)"
        if current_key
        else "Cole sua chave de API do SteamGridDB"
    )
    api_key = click.prompt(prompt, default=current_key, show_default=False).strip()

    if not api_key:
        console.print("[yellow]Nenhuma chave configurada. As capas nao serao baixadas.[/yellow]")
        return

    current["steamgriddb_api_key"] = api_key
    save_config_file(current)

    console.print()
    console.print("[bold green]Chave salva com sucesso.[/bold green]")
    console.print("[dim]Agora rode python -m steam_epic_bridge.main sync[/dim]")
    console.print()


@cli.command()
def status() -> None:
    """Mostra o estado atual do Steam, Epic e artworks."""
    settings = get_settings()
    _configure_logging(settings)
    try:
        data = get_status(settings)
    except (EpicAuthError, EpicLibraryError, SteamShortcutsError) as exc:
        raise click.ClickException(str(exc)) from exc

    table = Table(title="Steam Epic Bridge - Status", border_style="blue")
    table.add_column("Campo", style="bold")
    table.add_column("Valor", overflow="fold")

    labels = {
        "steam_root": "Steam instalado em",
        "steam_user_id": "Usuario Steam detectado",
        "shortcuts_path": "Arquivo shortcuts.vdf",
        "epic_games": "Jogos na biblioteca Epic",
        "epic_shortcuts": "Atalhos Epic ja no Steam",
        "artwork_enabled": "Capas automaticas (SteamGridDB)",
    }

    for key, value in data.items():
        label = labels.get(key, key)
        if key == "artwork_enabled":
            value = "Configurada" if value else "Sem chave - rode setup"
        table.add_row(label, str(value))

    console.print()
    console.print(table)
    console.print()


@cli.command(name="doctor")
def doctor_cmd() -> None:
    """Executa um diagnostico rapido do ambiente."""
    settings = get_settings()
    _configure_logging(settings)
    data = doctor(settings)

    table = Table(title="Steam Epic Bridge - Diagnostico", border_style="cyan")
    table.add_column("Check", style="bold")
    table.add_column("Resultado", overflow="fold")

    checks = [
        ("Steam instalado", "OK" if data["steam_root_exists"] else "Falhou"),
        ("Steam user id", data["steam_user_id"] or "Nao detectado"),
        ("Config do Steam", "OK" if data["steam_config_ready"] else "Nao encontrada"),
        ("Arquivo shortcuts.vdf", data["shortcuts_path"] or "Nao encontrado"),
        ("Backup disponivel", "Sim" if data["backup_available"] else "Nao"),
        ("Legendary", data["legendary_bin"]),
        ("Epic autenticada", "OK" if data["epic_authenticated"] else data["epic_auth_error"] or "Falhou"),
        ("Biblioteca Epic", str(data["epic_games"]) if data["epic_games"] is not None else data["epic_library_error"] or "Indisponivel"),
        ("SteamGridDB", "Configurada" if data["artwork_enabled"] else "Sem chave"),
    ]

    console.print()
    for label, value in checks:
        table.add_row(label, str(value))
    console.print(table)
    console.print()


@cli.command()
@click.option("--no-artwork", is_flag=True, help="Nao baixa artes do SteamGridDB.")
@click.option("--installed-only", is_flag=True, help="Sincroniza apenas jogos ja instalados.")
@click.option("--dry-run", is_flag=True, help="Mostra o que seria criado sem alterar o Steam.")
def sync(no_artwork: bool, installed_only: bool, dry_run: bool) -> None:
    """Sincroniza jogos da Epic como atalhos na biblioteca do Steam."""
    settings = get_settings()
    _configure_logging(settings)

    if is_steam_running():
        console.print()
        console.print("[bold red]O Steam esta aberto.[/bold red]")
        console.print("Feche o Steam completamente antes de sincronizar.")
        console.print()
        return

    console.print()

    if not settings.steamgriddb_api_key and not no_artwork:
        console.print(
            "[yellow]Chave SteamGridDB nao configurada - capas nao serao baixadas.[/yellow]\n"
            "[dim]Configure com: python -m steam_epic_bridge.main setup[/dim]\n"
        )

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            sync_task = progress.add_task("[cyan]Sincronizando biblioteca...", total=None)

            def update_progress(title: str, current: int = 0, total: int = 1) -> None:
                progress.update(sync_task, description=f"[cyan]Baixando capas: [bold]{title}[/bold] ({current}/{total})")

            result = sync_library(
                settings,
                download_artwork=not no_artwork,
                installed_only=installed_only,
                dry_run=dry_run,
                progress_callback=update_progress,
            )
            progress.update(sync_task, description="[green]Sincronizacao completa!", completed=100)
    except (EpicAuthError, EpicLibraryError, SteamShortcutsError) as exc:
        raise click.ClickException(str(exc)) from exc

    if dry_run:
        console.print(f"[bold cyan]Dry-run concluido.[/bold cyan] Novos atalhos previstos: {result.planned}")
        console.print(f"Ja existentes: {result.skipped}")
        console.print()
        return

    console.print("[bold green]Sincronizacao concluida.[/bold green]")
    console.print(f"  Criados:        [cyan]{result.created}[/cyan]")
    console.print(f"  Ja existiam:    [dim]{result.skipped}[/dim]")
    if result.artwork_downloaded:
        console.print(f"  Capas baixadas: [magenta]{result.artwork_downloaded}[/magenta]")
    if result.backup_path:
        console.print(f"  Backup salvo em: [dim]{result.backup_path}[/dim]")

    console.print()
    console.print("[dim]Feche e reabra o Steam para ver os jogos na biblioteca.[/dim]")
    console.print()


@cli.command(name="clean")
def clean_cmd() -> None:
    """Remove todos os atalhos Epic da biblioteca do Steam."""
    settings = get_settings()
    _configure_logging(settings)

    if is_steam_running():
        console.print()
        console.print("[bold red]O Steam esta aberto.[/bold red]")
        console.print("Feche o Steam completamente antes de limpar.")
        console.print()
        return

    try:
        result = clean(settings)
    except SteamShortcutsError as exc:
        raise click.ClickException(str(exc)) from exc
    console.print(f"[bold]Atalhos removidos:[/bold] {result.removed}")


@cli.command(name="clear-art")
def clear_art_cmd() -> None:
    """Remove apenas as imagens baixadas, sem apagar os atalhos do Steam."""
    settings = get_settings()
    _configure_logging(settings)

    try:
        removed = clear_art(settings)
    except SteamShortcutsError as exc:
        raise click.ClickException(str(exc)) from exc

    console.print(f"[bold]Arquivos de artwork removidos:[/bold] {removed}")


@cli.command(name="repair")
def repair_cmd() -> None:
    """Corrige caminhos de icones e limpa duplicatas na pasta grid."""
    settings = get_settings()
    _configure_logging(settings)

    if is_steam_running():
        console.print()
        console.print("[bold red]O Steam esta aberto.[/bold red]")
        console.print("Feche o Steam completamente antes de reparar.")
        console.print()
        return

    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console,
        ) as progress:
            repair_task = progress.add_task("[cyan]Reparando biblioteca...", total=100)

            def update_progress(title: str, current: int = 0, total: int = 100) -> None:
                completed = int((current / total) * 100) if total > 0 else 0
                progress.update(
                    repair_task,
                    description=f"[cyan]{title}[/cyan]",
                    completed=completed,
                )

            result = repair(settings, progress_callback=update_progress)
            progress.update(repair_task, description="[green]Reparo concluido!", completed=100)
    except SteamShortcutsError as exc:
        raise click.ClickException(str(exc)) from exc

    console.print("[bold green]Reparo concluido.[/bold green]")
    console.print(f"  Icones reconstruidos: [cyan]{result['rebuilt_icons']}[/cyan]")
    console.print(f"  Atalhos corrigidos: [cyan]{result['updated_paths']}[/cyan]")
    console.print(f"  Arquivos removidos: [cyan]{result['cleaned_files']}[/cyan]")
    console.print()


@cli.command(name="restore-backup")
def restore_backup_cmd() -> None:
    """Restaura o ultimo backup do shortcuts.vdf."""
    settings = get_settings()
    _configure_logging(settings)

    if is_steam_running():
        console.print()
        console.print("[bold red]O Steam esta aberto.[/bold red] Feche o Steam antes de restaurar um backup.")
        console.print()
        return

    try:
        result = restore(settings)
    except SteamShortcutsError as exc:
        raise click.ClickException(str(exc)) from exc

    console.print(f"[bold green]Backup restaurado com sucesso.[/bold green] Origem: {result.backup_path}")


@cli.command(name="reset-all")
def reset_all_cmd() -> None:
    """Desfaz tudo que o app fez: restaura backup e limpa atalhos/imagens/cache."""
    settings = get_settings()
    _configure_logging(settings)

    if is_steam_running():
        console.print()
        console.print("[bold red]O Steam esta aberto.[/bold red] Feche o Steam antes de resetar tudo.")
        console.print()
        return

    if not click.confirm(
        "Deseja realmente resetar tudo e tentar voltar o Steam ao estado anterior?",
        default=False,
    ):
        console.print("[yellow]Operacao cancelada.[/yellow]")
        return

    try:
        result = reset_all(settings)
    except SteamShortcutsError as exc:
        raise click.ClickException(str(exc)) from exc

    console.print("[bold green]Reset concluido.[/bold green]")
    if result.restored_backup and result.backup_path:
        console.print(f"  Backup restaurado: [dim]{result.backup_path}[/dim]")
    else:
        console.print(f"  Atalhos Epic removidos: [cyan]{result.removed_shortcuts}[/cyan]")
    console.print(f"  Imagens removidas: [cyan]{result.removed_artwork}[/cyan]")
    console.print(f"  Cache limpo: [cyan]{result.cleared_cache}[/cyan]")
    console.print()


@cli.command()
def gui() -> None:
    """Inicia a interface grafica."""
    run_gui()


@cli.command()
@click.option("--remove", is_flag=True, help="Remove a tarefa agendada.")
def schedule(remove: bool) -> None:
    """Agenda uma sincronizacao automatica diaria no Windows."""
    success, msg = unregister_task() if remove else register_task()
    if success:
        console.print(f"[bold green]{msg}[/bold green]")
    else:
        console.print("[bold red]Falha ao agendar tarefa.[/bold red]")
        console.print(f"[dim]{msg}[/dim]")


if __name__ == "__main__":
    cli()
