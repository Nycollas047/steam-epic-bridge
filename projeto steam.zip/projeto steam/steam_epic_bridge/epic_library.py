from __future__ import annotations

import json
import subprocess

from steam_epic_bridge.config import Settings
from steam_epic_bridge.models import EpicGame


class EpicLibraryError(RuntimeError):
    pass


def _run_legendary_json(settings: Settings, *args: str) -> list[dict]:
    try:
        result = subprocess.run(
            [settings.legendary_bin, *args, "--json"],
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except FileNotFoundError as exc:
        raise EpicLibraryError("O executavel 'legendary' nao foi encontrado.") from exc

    if result.returncode != 0:
        detail = result.stderr.strip() or result.stdout.strip()
        raise EpicLibraryError(f"Falha ao consultar a biblioteca Epic. {detail}".strip())

    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise EpicLibraryError("Resposta invalida do Legendary ao listar jogos.") from exc

    if not isinstance(payload, list):
        raise EpicLibraryError("Formato inesperado da biblioteca Epic.")
    return payload


def _launch_command_installed(app_name: str) -> str:
    """Lança via legendary (direto, sem abrir o launcher da Epic). Requer jogo instalado."""
    return f'legendary launch "{app_name}"'


def _launch_command_any(app_name: str) -> str:
    """Lança via protocolo URL da Epic. Funciona para jogos instalados E não instalados.
    Se não instalado, a Epic abre e oferece o download automaticamente.
    """
    return f'com.epicgames.launcher://apps/{app_name}?action=launch&silent=true'


def list_games(
    settings: Settings,
    include_uninstalled: bool = True,
    progress_callback: callable | None = None,
) -> list[EpicGame]:
    # 'list' é o comando atual do legendary; 'list-games' é o alias legado — ambos funcionam.
    # Tentamos 'list' primeiro (versão moderna), com fallback para 'list-games'.
    for cmd in ("list", "list-games"):
        try:
            payload = _run_legendary_json(settings, cmd)
            break
        except EpicLibraryError:
            if cmd == "list-games":
                raise
            # tenta o próximo comando
    else:
        raise EpicLibraryError("Nenhum comando de listagem funcionou no legendary.")

    games: list[EpicGame] = []
    total = len(payload)
    
    for i, item in enumerate(payload):
        app_name = item.get("app_name") or item.get("appName")
        title = item.get("app_title") or item.get("title") or app_name
        if not app_name or not title:
            continue
        
        if progress_callback:
            progress_callback(f"Lendo info: {title}", i + 1, total)

        install = item.get("install_path") or item.get("installPath")
        is_installed = bool(install)

        # Jogos instalados usam legendary (mais rápido, sem abrir o launcher).
        # Jogos NÃO instalados usam o protocolo URL da Epic: abre o launcher
        # e inicia o download/instalação automaticamente ao clicar em Jogar no Steam.
        launch_cmd = _launch_command_installed(app_name) if is_installed else _launch_command_any(app_name)

        game = EpicGame(
            app_name=app_name,
            title=title,
            launch_command=launch_cmd,
            launch_executable=None,
            install_path=install,
            icon_path=None,
            is_installed=is_installed,
        )
        games.append(game)

    games.sort(key=lambda game: game.title.lower())
    return games
