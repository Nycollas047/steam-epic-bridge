from __future__ import annotations

import json
import shutil
import subprocess
import sys

from steam_epic_bridge.config import Settings


class EpicAuthError(RuntimeError):
    pass


def _run_legendary(settings: Settings, *args: str) -> subprocess.CompletedProcess[str]:
    command = [settings.legendary_bin, *args]
    try:
        return subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
    except FileNotFoundError as exc:
        raise EpicAuthError(
            "Nao foi possivel encontrar o comando 'legendary'. Instale-o e autentique sua conta Epic antes do sync."
        ) from exc


def ensure_authenticated(settings: Settings) -> None:
    result = _run_legendary(settings, "status", "--json")
    if result.returncode != 0:
        stderr = result.stderr.strip() or result.stdout.strip()
        raise EpicAuthError(
            "Legendary nao esta autenticado ou nao respondeu corretamente."
            + (f" Detalhe: {stderr}" if stderr else "")
        )

    try:
        payload = json.loads(result.stdout)
    except json.JSONDecodeError as exc:
        raise EpicAuthError("Nao foi possivel interpretar a resposta de autenticacao do Legendary.") from exc

    if not payload.get("account"):
        raise EpicAuthError("Nenhuma conta Epic autenticada encontrada no Legendary.")


def login(settings: Settings, sid: str | None = None) -> None:
    """Realiza o login no Legendary usando um SID da Epic Games."""
    args = ["auth"]
    if sid:
        args.extend(["--sid", sid])

    result = _run_legendary(settings, *args)
    if result.returncode == 0:
        return

    raw = result.stderr.strip() or result.stdout.strip()

    if "JSONDecodeError" in raw or "exchange code" in raw.lower():
        raise EpicAuthError(
            "O codigo SID expirou ou e invalido.\n\n"
            "O SID expira em poucos segundos. Tente novamente e cole o SID imediatamente."
        )
    if "No saved credentials" in raw:
        raise EpicAuthError(
            "Nenhuma credencial salva encontrada.\n"
            "Use o botao 'Conectar Conta Epic' para fazer login."
        )

    lines = [line.strip() for line in raw.splitlines() if line.strip()]
    last_meaningful = lines[-1] if lines else "Erro desconhecido"
    raise EpicAuthError(f"Falha no login: {last_meaningful}")


def login_interactive(settings: Settings) -> None:
    """Abre uma nova janela de terminal para o usuario fazer login interativo no Legendary."""
    legendary = settings.legendary_bin
    
    if sys.platform == "win32":
        if " " in legendary:
            legendary = f'"{legendary}"'
        command = (
            'start "Login Epic Games (Legendary)" /WAIT cmd /c '
            f'"{legendary} auth && echo. && echo Login concluido! Fechando em 3s... && timeout /t 3 >nul"'
        )
        result = subprocess.run(command, shell=True, check=False)
        if result.returncode != 0:
            raise EpicAuthError("O processo de login interativo foi interrompido ou falhou.")
    else:
        # Linux / macOS: tenta detectar e usar emuladores de terminal comuns
        terminals = [
            ("gnome-terminal", ["--", legendary, "auth"]),
            ("konsole", ["-e", legendary, "auth"]),
            ("xfce4-terminal", ["-e", f"{legendary} auth"]),
            ("lxterminal", ["-e", legendary, "auth"]),
            ("mate-terminal", ["-e", legendary, "auth"]),
            ("xterm", ["-e", legendary, "auth"]),
        ]
        
        success = False
        for term, args in terminals:
            if shutil.which(term):
                try:
                    subprocess.run([term, *args], check=True)
                    success = True
                    break
                except Exception:
                    continue
                    
        if not success:
            raise EpicAuthError(
                "Nao foi possivel abrir uma janela de terminal automaticamente.\n"
                f"Por favor, execute o comando '{legendary} auth' no seu terminal manualmente."
            )

    try:
        ensure_authenticated(settings)
    except EpicAuthError as exc:
        raise EpicAuthError("O login nao foi concluido com sucesso.") from exc
