from __future__ import annotations

import logging
import re
import requests
from pathlib import Path
from PIL import Image
from dataclasses import dataclass

from steam_epic_bridge.config import Settings
from steam_epic_bridge.artwork import _session, _download_asset, _save_image
from steam_epic_bridge.models import EpicGame

LOGGER = logging.getLogger(__name__)

@dataclass
class ArtworkIssue:
    appid: str
    file_path: Path
    issue_type: str
    current_size: tuple[int, int]
    game_name: str | None = None

class ArtworkDoctor:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._name_cache: dict[str, str] = {}

    def _load_names(self):
        from steam_epic_bridge.steam_shortcuts import _load_shortcuts, _iter_entries
        if not self.settings.shortcuts_path:
            return
        payload = _load_shortcuts(self.settings.shortcuts_path)
        for _, entry in _iter_entries(payload):
            appid = entry.get("appid", 0)
            if appid:
                # Convert back to unsigned 32-bit if needed, or just handle both
                unsigned = appid & 0xFFFFFFFF
                name = entry.get("appname")
                if name:
                    self._name_cache[str(unsigned)] = name

    def scan(self, progress_callback: callable | None = None) -> list[ArtworkIssue]:
        self._load_names()
        grid_dir = self.settings.grid_dir
        if not grid_dir or not grid_dir.exists():
            return []

        issues = []
        # pattern matches {appid}p.ext, {appid}.ext, {appid}_hero.ext etc.
        files = list(grid_dir.glob("*"))
        total = len(files)

        for i, f in enumerate(files):
            if f.suffix.lower() not in [".png", ".jpg", ".jpeg"]:
                continue
                
            if progress_callback:
                progress_callback(f"Analisando {f.name}", i + 1, total)

            try:
                # Handle large images safely
                Image.MAX_IMAGE_PIXELS = 100000000 
                with Image.open(f) as img:
                    w, h = img.size
                    ratio = w / h
                    
                    appid_match = re.match(r"^(\d+)(p|_hero|_logo|_icon)?$", f.stem)
                    if not appid_match:
                        continue
                    
                    appid = appid_match.group(1)
                    suffix = appid_match.group(2) or ""

                    # Detection Logic:
                    # 1. Poster ('p' suffix) should be vertical (~0.66 ratio)
                    if suffix == "p":
                        if ratio > 1.0: # Horizontal image used as poster
                            issues.append(ArtworkIssue(appid, f, "poster_horizontal", (w, h)))
                        elif w < 300 or h < 450: # Low Res Poster
                            issues.append(ArtworkIssue(appid, f, "low_res_poster", (w, h)))
                        elif abs(ratio - 0.66) > 0.2: # Stretched/Wrong ratio for poster
                            issues.append(ArtworkIssue(appid, f, "bad_aspect_ratio_poster", (w, h)))
                    
                    # 2. Main Grid (no suffix) was traditionally horizontal (460x215)
                    elif suffix == "":
                        if ratio < 1.0: # Vertical image used as horizontal grid
                            issues.append(ArtworkIssue(appid, f, "grid_vertical", (w, h)))
                        elif w < 400: # Very small horizontal grid
                            issues.append(ArtworkIssue(appid, f, "low_res_grid", (w, h)))

                    # 3. Hero (_hero suffix) should be 16:9 or similar
                    elif suffix == "_hero":
                        if ratio < 1.4: # Too square or vertical for a Hero
                            issues.append(ArtworkIssue(appid, f, "bad_aspect_ratio_hero", (w, h)))
                        elif w < 1280: # Below HD resolution
                            issues.append(ArtworkIssue(appid, f, "low_res_hero", (w, h)))

                    # 4. Logo (_logo suffix) should be transparent (already checked by user, but good to note)
                    elif suffix == "_logo":
                        if w < 200:
                            issues.append(ArtworkIssue(appid, f, "low_res_logo", (w, h)))
            except Exception as exc:
                LOGGER.debug("Erro ao analisar %s: %s", f.name, exc)

        return issues

    def get_game_name(self, appid: str) -> str | None:
        if appid in self._name_cache:
            return self._name_cache[appid]

        # Try Steam Store API first (for native games)
        try:
            resp = requests.get(f"https://store.steampowered.com/api/appdetails?appids={appid}", timeout=10)
            if resp.status_code == 200:
                data = resp.json()
                if data.get(appid, {}).get("success"):
                    name = data[appid]["data"]["name"]
                    self._name_cache[appid] = name
                    return name
        except Exception:
            pass

        # TODO: For shortcuts, we'd need to parse shortcuts.vdf and match appid.
        # For now, we'll try to guess or use SteamGridDB search by appid.
        return None

    def repair_issue(self, issue: ArtworkIssue) -> bool:
        """Attempts to download a correct vertical poster for the appid."""
        if not self.settings.steamgriddb_api_key:
            return False

        name = self.get_game_name(issue.appid)
        
        session = _session(self.settings)
        game_id = None
        
        # 1. Tenta buscar pelo appid no SteamGridDB (funciona para jogos nativos)
        if issue.appid.isdigit() and int(issue.appid) < 2**31:
            try:
                resp = session.get(f"https://www.steamgriddb.com/api/v2/games/steam/{issue.appid}", timeout=10)
                if resp.status_code == 200:
                    game_id = resp.json().get("data", {}).get("id")
            except Exception:
                pass

        # 2. Se não encontrou pelo AppID (atalho ou jogo não cadastrado pelo ID), tenta pelo nome
        if not game_id and name:
            from steam_epic_bridge.artwork import _search_game_id
            # Cria um objeto mock para reutilizar a lógica de busca do artwork.py
            dummy_game = EpicGame(app_name="mock", title=name, launch_command="", is_installed=False)
            try:
                game_id = _search_game_id(session, dummy_game)
            except Exception:
                pass

        if not game_id:
            return False

        # 3. Faz o download do Poster vertical (grid) com filtros de estilo/mimetype
        params = {}
        if self.settings.artwork_style != "any":
            params["styles"] = self.settings.artwork_style
            
        if self.settings.prefer_animated:
            params["mimetypes"] = "image/png,image/gif" # PNG Animado ou GIF
            if "styles" in params:
                 params["styles"] += ",animated"
            else:
                 params["styles"] = "animated"
        
        poster_url = _download_asset(session, "grids", game_id, params=params)
        if not poster_url:
            # Fallback for when specific style or animated is not found
            poster_url = _download_asset(session, "grids", game_id)
            
        if poster_url:
            ext = Path(poster_url).suffix or ".png"
            dest = self.settings.grid_dir / f"{issue.appid}p{ext}"
            return _save_image(poster_url, dest)

        return False
