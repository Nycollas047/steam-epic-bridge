from __future__ import annotations

import logging

from steam_epic_bridge.artwork import ArtworkError, clear_artwork_cache, download_artwork_for_game
from steam_epic_bridge.config import Settings
from steam_epic_bridge.epic_auth import ensure_authenticated
from steam_epic_bridge.epic_library import list_games
from steam_epic_bridge.models import ResetResult, SyncResult
from steam_epic_bridge.steam_shortcuts import (
    SteamShortcutsError,
    add_games,
    compute_appid,
    ensure_shortcuts_file,
    existing_shortcuts_count,
    latest_backup_path,
    plan_add_games,
    remove_epic_shortcuts,
    restore_shortcuts_backup,
    clear_only_artwork,
    update_artwork_paths,
    scan_and_fix_artworks,
    repair_library,
)


LOGGER = logging.getLogger(__name__)


def get_status(settings: Settings) -> dict:
    shortcuts_path = ensure_shortcuts_file(settings)

    # Tenta obter dados da Epic, mas degrada graciosamente se Legendary não estiver
    # disponível ou autenticado (para que a GUI não crashe na inicialização).
    try:
        games = list_games(settings)
        epic_games = len(games)
    except Exception:
        epic_games = "Indisponivel"

    try:
        existing = existing_shortcuts_count(settings)
    except Exception:
        existing = 0

    return {
        "steam_root": str(settings.steam_root),
        "steam_user_id": settings.steam_user_id,
        "shortcuts_path": str(shortcuts_path),
        "epic_games": epic_games,
        "epic_shortcuts": existing,
        "artwork_enabled": bool(settings.steamgriddb_api_key),
    }


def clean(settings: Settings) -> SyncResult:
    result = SyncResult()
    result.removed = remove_epic_shortcuts(settings)
    return result


def restore(settings: Settings) -> SyncResult:
    result = SyncResult()
    result.backup_path = restore_shortcuts_backup(settings)
    return result


def clear_art(settings: Settings) -> int:
    return clear_only_artwork(settings)


def repair(settings: Settings, progress_callback: callable | None = None) -> dict:
    return repair_library(settings, progress_callback=progress_callback)



def reset_all(settings: Settings) -> ResetResult:
    removed_artwork = clear_only_artwork(settings)
    cleared_cache = clear_artwork_cache()

    try:
        backup = restore_shortcuts_backup(settings)
        return ResetResult(
            restored_backup=True,
            removed_artwork=removed_artwork,
            cleared_cache=cleared_cache,
            backup_path=backup,
        )
    except SteamShortcutsError:
        removed_shortcuts = remove_epic_shortcuts(settings)
        return ResetResult(
            restored_backup=False,
            removed_shortcuts=removed_shortcuts,
            removed_artwork=removed_artwork,
            cleared_cache=cleared_cache,
        )


def doctor(settings: Settings) -> dict:
    shortcuts_path = settings.shortcuts_path
    backup_path = latest_backup_path(shortcuts_path) if shortcuts_path else None
    steam_config_ready = bool(shortcuts_path and shortcuts_path.parent.exists())

    try:
        ensure_authenticated(settings)
        epic_authenticated = True
        epic_auth_error = None
    except Exception as exc:
        epic_authenticated = False
        epic_auth_error = str(exc)

    try:
        epic_games = len(list_games(settings)) if epic_authenticated else None
        epic_library_error = None
    except Exception as exc:
        epic_games = None
        epic_library_error = str(exc)

    return {
        "steam_root_exists": settings.steam_root.exists(),
        "steam_user_id": settings.steam_user_id,
        "steam_config_ready": steam_config_ready,
        "shortcuts_path": str(shortcuts_path) if shortcuts_path else None,
        "backup_available": bool(backup_path and backup_path.exists()),
        "legendary_bin": settings.legendary_bin,
        "epic_authenticated": epic_authenticated,
        "epic_auth_error": epic_auth_error,
        "epic_games": epic_games,
        "epic_library_error": epic_library_error,
        "artwork_enabled": bool(settings.steamgriddb_api_key),
        "discovered_steam_roots": [str(path) for path in settings.discovery.steam_roots],
        "discovered_steam_user_ids": list(settings.discovery.steam_user_ids),
        "discovered_legendary_bins": [str(path) for path in settings.discovery.legendary_bins],
        "discovered_epic_launchers": [str(path) for path in settings.discovery.epic_launcher_bins],
    }


def sync_library(
    settings: Settings,
    download_artwork: bool = True,
    installed_only: bool = False,
    dry_run: bool = False,
    progress_callback: callable | None = None,
) -> SyncResult:
    ensure_authenticated(settings)
    games = list_games(settings, progress_callback=progress_callback)

    if not games:
        return SyncResult()

    # Filtra apenas instalados se solicitado
    if installed_only:
        games = [g for g in games if g.is_installed]

    if not games:
        return SyncResult()

    planned_created, planned_skipped = plan_add_games(settings, games)
    if dry_run:
        return SyncResult(planned=planned_created, skipped=planned_skipped)

    created, skipped, backup = add_games(settings, games)
    result = SyncResult(
        created=created,
        skipped=skipped,
        planned=planned_created,
        backup_path=backup,
    )

    if not download_artwork or not settings.steamgriddb_api_key:
        return result

    total = len(games)
    for i, game in enumerate(games, 1):
        if progress_callback:
            progress_callback(game.title, i, total)
        try:
            appid = compute_appid(settings, game)
            result.artwork_downloaded += download_artwork_for_game(settings, game, appid)
        except ArtworkError as exc:
            LOGGER.warning("Falha ao baixar artwork para %s: %s", game.title, exc)
        except Exception as exc:  # pragma: no cover
            LOGGER.warning("Erro inesperado ao baixar artwork para %s: %s", game.title, exc)

    update_artwork_paths(settings)
    
    # Nova faxina para remover duplicatas e erros de imagem
    scan_and_fix_artworks(settings)

    return result
