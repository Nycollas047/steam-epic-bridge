from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from steam_epic_bridge.discovery import DiscoveryResult, discover_environment


APP_NAME = "Steam Epic Bridge"
APP_ID_PREFIX = "epic-"
SHORTCUT_TAG = "Epic Games"

if os.name == "nt":
    _CONFIG_DIR = Path(os.getenv("APPDATA", "~/AppData/Roaming")).expanduser() / "steam-epic-bridge"
else:
    _CONFIG_DIR = Path(os.getenv("XDG_CONFIG_HOME", "~/.config")).expanduser() / "steam-epic-bridge"
_CONFIG_FILE = _CONFIG_DIR / "config.json"


def load_config_file() -> dict:
    if not _CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(_CONFIG_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def save_config_file(data: dict) -> None:
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _steam_root(file_config: dict, discovery: DiscoveryResult) -> Path:
    env_value = os.getenv("STEAM_PATH")
    if env_value:
        return Path(env_value).expanduser()

    configured = file_config.get("steam_root")
    if configured:
        return Path(configured).expanduser()

    if discovery.preferred_steam_root:
        return discovery.preferred_steam_root

    return Path(os.getenv("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Steam"


def _steam_user_id(root: Path, file_config: dict, discovery: DiscoveryResult) -> str | None:
    forced = os.getenv("SEB_STEAM_USER_ID")
    if forced:
        return forced

    configured = file_config.get("steam_user_id")
    if configured:
        return str(configured)

    preferred = discovery.preferred_steam_user_id
    if preferred:
        return preferred

    userdata = root / "userdata"
    if not userdata.exists():
        return None

    try:
        numeric_dirs = [path for path in userdata.iterdir() if path.is_dir() and path.name.isdigit()]
    except OSError:
        return None

    if not numeric_dirs:
        return None
    if len(numeric_dirs) == 1:
        return numeric_dirs[0].name
    return max(numeric_dirs, key=lambda p: p.stat().st_mtime).name


def _legendary_binary(file_config: dict, discovery: DiscoveryResult) -> str:
    configured = os.getenv("SEB_LEGENDARY_PATH") or file_config.get("legendary_bin")
    if configured:
        return configured

    if discovery.preferred_legendary_bin:
        return str(discovery.preferred_legendary_bin)

    return "legendary"


def _steamgriddb_api_key(file_config: dict) -> str | None:
    return os.getenv("STEAMGRIDDB_API_KEY") or file_config.get("steamgriddb_api_key")



@dataclass(slots=True)
class Settings:
    steam_root: Path
    steam_user_id: str | None
    legendary_bin: str
    steamgriddb_api_key: str | None
    debug: bool
    prefer_animated: bool = False
    artwork_style: str = "any"
    discovery: DiscoveryResult = field(default_factory=discover_environment)


    @property
    def userdata_dir(self) -> Path | None:
        if not self.steam_user_id:
            return None
        return self.steam_root / "userdata" / self.steam_user_id

    @property
    def config_dir(self) -> Path | None:
        if not self.userdata_dir:
            return None
        return self.userdata_dir / "config"

    @property
    def shortcuts_path(self) -> Path | None:
        if not self.config_dir:
            return None
        return self.config_dir / "shortcuts.vdf"

    @property
    def grid_dir(self) -> Path | None:
        if not self.config_dir:
            return None
        return self.config_dir / "grid"

    @property
    def log_path(self) -> Path:
        return _CONFIG_DIR / "sync.log"

    @property
    def epic_launcher_bin(self) -> Path | None:
        return self.discovery.preferred_epic_launcher_bin


def get_settings() -> Settings:
    file_config = load_config_file()
    discovery = discover_environment()
    steam_root = _steam_root(file_config, discovery)

    return Settings(
        steam_root=steam_root,
        steam_user_id=_steam_user_id(steam_root, file_config, discovery),
        legendary_bin=_legendary_binary(file_config, discovery),
        steamgriddb_api_key=_steamgriddb_api_key(file_config),
        debug=os.getenv("SEB_DEBUG", "").strip() in {"1", "true", "TRUE", "yes"},
        prefer_animated=file_config.get("prefer_animated", False),
        artwork_style=file_config.get("artwork_style", "any"),
    )
