from __future__ import annotations

import logging

from steam_epic_bridge.artwork import clear_artwork_cache, download_artwork_batch
from steam_epic_bridge.artwork_doctor import ArtworkDoctor
from steam_epic_bridge.config import Settings
from steam_epic_bridge.epic_auth import ensure_authenticated
from steam_epic_bridge.epic_library import list_games
from steam_epic_bridge.models import ResetResult, SyncResult
from steam_epic_bridge.steam_shortcuts import (
    SteamShortcutsError,
    add_games,
    clear_only_artwork,
    compute_appid,
    ensure_shortcuts_file,
    existing_shortcuts_count,
    latest_backup_path,
    plan_add_games,
    remove_epic_shortcuts,
    repair_library,
    restore_shortcuts_backup,
)


LOGGER = logging.getLogger(__name__)


class SyncEngine:
    """Motor central de sincronizacao para GUI e fluxos mais ricos."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self._games = []

    def get_status(self) -> dict:
        shortcuts_path = ensure_shortcuts_file(self.settings)
        try:
            self._games = list_games(self.settings)
            epic_count = len(self._games)
        except Exception:
            epic_count = "Indisponivel"

        try:
            steam_count = existing_shortcuts_count(self.settings)
        except Exception:
            steam_count = 0

        return {
            "steam_root": str(self.settings.steam_root),
            "steam_user_id": self.settings.steam_user_id,
            "shortcuts_path": str(shortcuts_path),
            "epic_games": epic_count,
            "epic_shortcuts": steam_count,
            "artwork_enabled": bool(self.settings.steamgriddb_api_key),
        }

    def doctor(self) -> dict:
        shortcuts_path = self.settings.shortcuts_path
        backup_path = latest_backup_path(shortcuts_path) if shortcuts_path else None
        status = self.get_status()

        try:
            ensure_authenticated(self.settings)
            epic_authenticated = True
            epic_auth_error = None
        except Exception as exc:
            epic_authenticated = False
            epic_auth_error = str(exc)

        return {
            "steam_root_exists": self.settings.steam_root.exists(),
            "steam_user_id": self.settings.steam_user_id,
            "steam_config_ready": bool(shortcuts_path and shortcuts_path.parent.exists()),
            "shortcuts_path": str(shortcuts_path) if shortcuts_path else None,
            "backup_available": bool(backup_path and backup_path.exists()),
            "legendary_bin": self.settings.legendary_bin,
            "epic_authenticated": epic_authenticated,
            "epic_auth_error": epic_auth_error,
            "epic_games": status.get("epic_games"),
            "epic_library_error": None if status.get("epic_games") != "Indisponivel" else "Biblioteca Epic indisponivel",
            "artwork_enabled": bool(self.settings.steamgriddb_api_key),
            "discovered_steam_roots": [str(path) for path in self.settings.discovery.steam_roots],
            "discovered_steam_user_ids": list(self.settings.discovery.steam_user_ids),
            "discovered_legendary_bins": [str(path) for path in self.settings.discovery.legendary_bins],
            "discovered_epic_launchers": [str(path) for path in self.settings.discovery.epic_launcher_bins],
        }

    def sync(
        self,
        download_artwork: bool = True,
        installed_only: bool = False,
        dry_run: bool = False,
        progress_callback: callable | None = None,
    ) -> SyncResult:
        ensure_authenticated(self.settings)
        games = list_games(self.settings, progress_callback=progress_callback)

        if installed_only:
            games = [game for game in games if game.is_installed]

        if not games:
            return SyncResult()

        planned_created, planned_skipped = plan_add_games(self.settings, games)
        if dry_run:
            return SyncResult(planned=planned_created, skipped=planned_skipped)

        created, skipped, backup = add_games(self.settings, games)
        result = SyncResult(
            created=created,
            skipped=skipped,
            planned=planned_created,
            backup_path=backup,
        )

        if download_artwork and self.settings.steamgriddb_api_key:
            games_with_appid: list[tuple] = []
            for game in games:
                try:
                    appid = compute_appid(self.settings, game)
                    games_with_appid.append((game, appid))
                except Exception:
                    LOGGER.exception("Falha ao calcular appid para %s", game.title)

            result.artwork_downloaded = download_artwork_batch(
                self.settings,
                games_with_appid,
                progress_callback=progress_callback,
            )

        repair_library(self.settings, progress_callback=progress_callback)
        return result

    def clean(self) -> SyncResult:
        return SyncResult(removed=remove_epic_shortcuts(self.settings))

    def restore(self) -> SyncResult:
        return SyncResult(backup_path=restore_shortcuts_backup(self.settings))

    def clear_art(self) -> int:
        return clear_only_artwork(self.settings)

    def repair(self, progress_callback: callable | None = None) -> dict:
        return repair_library(self.settings, progress_callback=progress_callback)

    def fix_steam_artworks(self, progress_callback: callable | None = None) -> int:
        doctor = ArtworkDoctor(self.settings)
        issues = doctor.scan(progress_callback=progress_callback)
        if not issues:
            return 0
        
        fixed = 0
        total = len(issues)
        for i, issue in enumerate(issues):
            if progress_callback:
                progress_callback(f"Corrigindo {issue.appid}...", i + 1, total)
            if doctor.repair_issue(issue):
                fixed += 1
        return fixed

    def reset_all(self) -> ResetResult:
        removed_artwork = clear_only_artwork(self.settings)
        cleared_cache = clear_artwork_cache()

        try:
            backup_path = restore_shortcuts_backup(self.settings)
            return ResetResult(
                restored_backup=True,
                removed_artwork=removed_artwork,
                cleared_cache=cleared_cache,
                backup_path=backup_path,
            )
        except SteamShortcutsError:
            removed_shortcuts = remove_epic_shortcuts(self.settings)
            return ResetResult(
                restored_backup=False,
                removed_shortcuts=removed_shortcuts,
                removed_artwork=removed_artwork,
                cleared_cache=cleared_cache,
            )
