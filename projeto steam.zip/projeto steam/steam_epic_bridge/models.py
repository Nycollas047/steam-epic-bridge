from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(slots=True)
class GameMetadata:
    steam_app_id: int | None = None
    release_date: str | None = None
    genres: list[str] | None = None
    cover_url: str | None = None
    source: str | None = None


@dataclass(slots=True)
class EpicGame:
    app_name: str
    title: str
    launch_command: str
    launch_executable: str | None = None
    install_path: str | None = None
    icon_path: str | None = None
    is_installed: bool = False
    metadata: GameMetadata | None = None


@dataclass(slots=True)
class SyncResult:
    created: int = 0
    skipped: int = 0
    planned: int = 0
    removed: int = 0
    artwork_downloaded: int = 0
    backup_path: Path | None = None


@dataclass(slots=True)
class ResetResult:
    restored_backup: bool = False
    removed_shortcuts: int = 0
    removed_artwork: int = 0
    cleared_cache: int = 0
    backup_path: Path | None = None
