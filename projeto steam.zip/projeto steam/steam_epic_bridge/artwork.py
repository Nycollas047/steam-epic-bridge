from __future__ import annotations

import json
import time
import concurrent.futures
import re
from pathlib import Path

import requests
from PIL import Image

from steam_epic_bridge.config import Settings, _CONFIG_DIR
from steam_epic_bridge.models import EpicGame


class ArtworkError(RuntimeError):
    pass


# Convenção de nomes do Steam para atalhos não-Steam:
#   Grid  (capa vertical 600x900):  {appid}p.png
#   Hero  (banner 1920x620):        {appid}_hero.png
#   Logo  (logo 800x320):           {appid}_logo.png
IMAGE_TYPES: dict[str, tuple[str, str]] = {
    "grid": ("grids", "p"),
    "hero": ("heroes", "_hero"),
    "logo": ("logos", "_logo"),
    "icon": ("icons", "_icon"),
}


def _session(settings: Settings) -> requests.Session:
    if not settings.steamgriddb_api_key:
        raise ArtworkError("STEAMGRIDDB_API_KEY nao configurada.")
    session = requests.Session()
    session.headers["Authorization"] = f"Bearer {settings.steamgriddb_api_key}"
    session.headers["User-Agent"] = "steam-epic-bridge/0.1"
    return session


_EDITION_SUFFIXES = (
    "complete edition",
    "the complete edition",
    "game of the year edition",
    "goty edition",
    "ultimate edition",
    "definitive edition",
    "deluxe edition",
    "premium edition",
    "gold edition",
    "legendary edition",
    "special edition",
    "remastered",
    "collection",
)


def _candidate_search_terms(game: EpicGame) -> list[str]:
    raw_terms = [game.title.strip()]
    metadata = game.metadata

    if metadata and metadata.source == "rawg" and game.title:
        raw_terms.append(game.title.replace(":", "").replace(" - ", " ").strip())

    cleaned_terms: list[str] = []
    seen: set[str] = set()

    def add_term(term: str) -> None:
        normalized_key = term.casefold().strip()
        if not normalized_key or normalized_key in seen:
            return
        seen.add(normalized_key)
        cleaned_terms.append(term.strip())

    for term in raw_terms:
        add_term(term)

        flattened = re.sub(r"[:\-_/]+", " ", term).strip()
        add_term(flattened)

        for suffix in _EDITION_SUFFIXES:
            pattern = re.compile(rf"[\s:\-–—]*{re.escape(suffix)}$", re.IGNORECASE)
            shortened = pattern.sub("", term).strip(" :-–—")
            if shortened and shortened != term:
                add_term(shortened)
                add_term(re.sub(r"[:\-_/]+", " ", shortened).strip())

        if ":" in term:
            add_term(term.split(":", 1)[0].strip())

        if " - " in term:
            add_term(term.split(" - ", 1)[0].strip())

    return cleaned_terms


def _search_game_id(session: requests.Session, game: EpicGame) -> int | None:
    metadata = game.metadata

    # Melhor caso: se IGDB encontrou Steam App ID, tentamos consultar por game/steam app id.
    if metadata and metadata.steam_app_id:
        try:
            response = session.get(
                f"https://www.steamgriddb.com/api/v2/games/steam/{metadata.steam_app_id}",
                timeout=20,
            )
            response.raise_for_status()
            data = response.json().get("data")
            if isinstance(data, dict) and data.get("id"):
                return data["id"]
        except requests.RequestException:
            pass

    for term in _candidate_search_terms(game):
        response = session.get(
            "https://www.steamgriddb.com/api/v2/search/autocomplete/" + requests.utils.quote(term),
            timeout=20,
        )
        response.raise_for_status()
        data = response.json().get("data") or []
        if data:
            return data[0].get("id")

    return None


def _download_asset(session: requests.Session, endpoint: str, game_id: int, params: dict | None = None) -> str | None:
    url = f"https://www.steamgriddb.com/api/v2/{endpoint}/game/{game_id}"
    response = session.get(url, params=params, timeout=20)
    response.raise_for_status()
    data = response.json().get("data") or []
    if not data:
        return None
    return data[0].get("url")


def _save_image(url: str, destination: Path) -> bool:
    # Não usamos a 'session' aqui porque o CDN (cdn2.steamgriddb.com) recusa a conexão
    # retornando 401 Unauthorized se o header 'Authorization: Bearer' estiver presente.
    # Fazemos uma requisição limpa sem headers de autorização.
    try:
        response = requests.get(url, timeout=30, headers={"User-Agent": "steam-epic-bridge/0.1"})
        response.raise_for_status()
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(response.content)
        return True
    except Exception:
        return False


def _save_icon_image(url: str, destination: Path) -> bool:
    try:
        response = requests.get(url, timeout=30, headers={"User-Agent": "steam-epic-bridge/0.1"})
        response.raise_for_status()
        destination.parent.mkdir(parents=True, exist_ok=True)

        temp_source = destination.with_suffix(".src")
        temp_source.write_bytes(response.content)
        try:
            with Image.open(temp_source) as image:
                image = image.convert("RGBA")
                image.save(destination, format="ICO", sizes=[(256, 256)])
        finally:
            if temp_source.exists():
                temp_source.unlink()
        return True
    except Exception:
        return False


def ensure_ico_file(source: Path, destination: Path | None = None) -> Path | None:
    if not source.exists():
        return None
    if source.suffix.lower() == ".ico":
        return source

    destination = destination or source.with_suffix(".ico")
    try:
        with Image.open(source) as image:
            image = image.convert("RGBA")
            image.save(destination, format="ICO", sizes=[(256, 256)])
        return destination
    except Exception:
        return None


_FAILED_SEARCH_FILE = _CONFIG_DIR / "failed_searches.json"

def _load_failed_searches() -> dict:
    if not _FAILED_SEARCH_FILE.exists():
        return {}
    try:
        return json.loads(_FAILED_SEARCH_FILE.read_text(encoding="utf-8"))
    except:
        return {}

def _save_failed_search(game_title: str) -> None:
    data = _load_failed_searches()
    data[game_title] = time.time()
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _FAILED_SEARCH_FILE.write_text(json.dumps(data), encoding="utf-8")

def _is_blacklisted(game_title: str) -> bool:
    data = _load_failed_searches()
    last_fail = data.get(game_title)
    if not last_fail:
        return False
    # Não tenta buscar de novo se falhou nos últimos 30 dias
    return (time.time() - last_fail) < (30 * 24 * 60 * 60)


def clear_artwork_cache() -> int:
    removed = 0
    if _FAILED_SEARCH_FILE.exists():
        try:
            _FAILED_SEARCH_FILE.unlink()
            removed += 1
        except OSError:
            pass
    return removed


def download_artwork_for_game(settings: Settings, game: EpicGame, appid: int) -> int:
    """Download síncrono legado (mantido para compatibilidade se necessário)"""
    if not settings.grid_dir:
        raise ArtworkError("Diretorio grid do Steam nao encontrado.")

    unsigned_appid = appid & 0xFFFFFFFF
    
    # Check which artworks are missing to avoid unnecessary API requests
    missing_endpoints = []
    for suffix, (endpoint, steam_suffix) in IMAGE_TYPES.items():
        found = False
        for ext in [".ico", ".png", ".jpg", ".jpeg"]:
            if (settings.grid_dir / f"{unsigned_appid}{steam_suffix}{ext}").exists():
                found = True
                break
        if not found:
            missing_endpoints.append((suffix, endpoint, steam_suffix))
            
    if not missing_endpoints:
        return 0

    if _is_blacklisted(game.title):
        return 0

    session = _session(settings)
    try:
        game_id = _search_game_id(session, game)
    except Exception:
        return 0

    if not game_id:
        _save_failed_search(game.title)
        return 0

    downloaded = 0
    for suffix, endpoint, steam_suffix in missing_endpoints:
        image_url = _download_asset(session, endpoint, game_id)
        if not image_url:
            continue
        if suffix == "icon":
            destination = settings.grid_dir / f"{unsigned_appid}{steam_suffix}.ico"
            saved = _save_icon_image(image_url, destination)
        else:
            extension = Path(image_url).suffix or ".png"
            destination = settings.grid_dir / f"{unsigned_appid}{steam_suffix}{extension}"
            saved = _save_image(image_url, destination)
        if saved:
            downloaded += 1
    return downloaded


def download_artwork_batch(
    settings: Settings, 
    games_with_appid: list[tuple[EpicGame, int]], 
    max_workers: int = 10,
    progress_callback: callable | None = None
) -> int:
    """Download paralelo de artes para uma lista de jogos."""
    if not settings.grid_dir:
        return 0
    
    total_downloaded = 0
    total_games = len(games_with_appid)

    def _task(game: EpicGame, appid: int, index: int):
        num = download_artwork_for_game(settings, game, appid)
        if progress_callback:
            progress_callback(game.title, index + 1, total_games)
        return num

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(_task, game, appid, i) 
            for i, (game, appid) in enumerate(games_with_appid)
        ]
        for future in concurrent.futures.as_completed(futures):
            try:
                total_downloaded += future.result()
            except Exception:
                pass
                
    return total_downloaded
