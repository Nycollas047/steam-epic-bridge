"""
PC Health Checker - Ponto de entrada principal
Uso:
  python main.py            # Inicia a GUI
  python main.py --cli      # Modo linha de comando
  python main.py --cli --format csv   # CLI com saída em CSV
"""
import argparse
import sys
import os
import io
import atexit

# Garante que o diretório raiz do projeto está no sys.path,
# independente de onde o usuário executa o script
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

# Suprime o erro cosmético do módulo wmi ao encerrar no Python 3.12+
# "Win32 exception occurred releasing IUnknown" — bug do wmi, não do nosso código
def _suppress_wmi_exit_noise():
    sys.stderr = io.StringIO()

atexit.register(_suppress_wmi_exit_noise)


def run_cli(export_format: str = "json"):
    from core.engine import Engine
    from scanners.hardware import scan_hardware
    from scanners.sistema import scan_sistema
    from scanners.apps import scan_apps
    from scanners.jogos import scan_jogos
    from scanners.drivers import scan_drivers
    from scanners.seguranca import scan_seguranca

    print("=" * 50)
    print("  PC Health Checker - Modo CLI")
    print("=" * 50)
    print("Iniciando varredura do sistema...\n")

    engine = Engine()
    engine.register_scanner(scan_hardware)
    engine.register_scanner(scan_sistema)
    engine.register_scanner(scan_apps)
    engine.register_scanner(scan_jogos)
    engine.register_scanner(scan_drivers)
    engine.register_scanner(scan_seguranca)

    try:
        report = engine.run_all()
    except Exception as e:
        print(f"[ERRO FATAL] Falha durante a varredura: {e}", file=sys.stderr)
        sys.exit(1)

    print("Resumo da Varredura:")
    print(f"  Total de itens : {report.summary.get('total_itens', 0)}")
    print(f"  Criticos       : {report.summary.get('criticos', 0)}")
    print(f"  Avisos         : {report.summary.get('avisos', 0)}")
    print(f"  OK             : {report.summary.get('ok', 0)}")
    print()

    # Imprime itens críticos e avisos no terminal
    from core.models import Severity
    for item in report.items:
        if item.severity in (Severity.CRITICAL, Severity.WARNING):
            tag = "[CRITICO]" if item.severity == Severity.CRITICAL else "[AVISO]  "
            print(f"  {tag} {item.category.value} / {item.name}: {item.description or item.value}")

    print()

    try:
        if export_format == "json":
            path = engine.reporter.export_json(report)
        elif export_format == "csv":
            path = engine.reporter.export_csv(report)
        elif export_format == "xml":
            path = engine.reporter.export_xml(report)
        else:
            path = engine.reporter.export_json(report)

        print(f"Relatorio exportado: {path}")
    except Exception as e:
        print(f"[ERRO] Falha ao exportar relatorio: {e}", file=sys.stderr)
        sys.exit(1)


def run_gui():
    try:
        import customtkinter  # noqa: F401
    except ImportError:
        print(
            "[ERRO] O pacote 'customtkinter' não está instalado.\n"
            "Execute:  pip install -r requirements.txt",
            file=sys.stderr
        )
        sys.exit(1)

    from gui.app import run_app
    run_app()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="PC Health Checker - Ferramenta de Diagnóstico de Sistema"
    )
    parser.add_argument(
        "--cli", action="store_true",
        help="Executar em modo linha de comando (sem GUI)"
    )
    parser.add_argument(
        "--format", choices=["json", "csv", "xml"], default="json",
        help="Formato de exportação do relatório (padrão: json)"
    )

    args = parser.parse_args()

    if args.cli:
        run_cli(args.format)
    else:
        run_gui()
