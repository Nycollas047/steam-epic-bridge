# 🖥️ PC Health Checker

Ferramenta de diagnóstico e análise de sistema para **Windows** e **Linux**. Varre hardware, sistema operacional, aplicativos, jogos, drivers e segurança — gerando relatórios estruturados com níveis de severidade.

---

## 🚀 Início Rápido

### Pré-requisitos

- Python 3.9 ou superior

### Instalação das Dependências

```bash
pip install -r requirements.txt
```

### Execução

**Interface Gráfica (GUI):**
```bash
python main.py
```

**Linha de Comando (CLI):**
```bash
python main.py --cli
```

**CLI com formato específico:**
```bash
python main.py --cli --format json   # padrão
python main.py --cli --format csv
python main.py --cli --format xml
```

---

## 📂 Estrutura do Projeto

```
pc-health-checker/
├── main.py                  # Ponto de entrada (GUI ou CLI)
├── requirements.txt         # Dependências Python
├── config/
│   └── rules.json           # Regras de severidade configuráveis
├── core/
│   ├── engine.py            # Orquestrador (execução paralela dos scanners)
│   ├── classifier.py        # Motor de classificação de severidade
│   ├── reporter.py          # Exportador (JSON / CSV / XML)
│   └── models.py            # Modelos de dados (Pydantic)
├── scanners/
│   ├── hardware.py          # CPU, RAM, Disco, GPU, Temperaturas
│   ├── sistema.py           # S.O., uptime, atualizações pendentes
│   ├── apps.py              # Processos e aplicativos em execução
│   ├── jogos.py             # Launchers (Steam, Epic, GOG)
│   ├── drivers.py           # Drivers assinados/problemáticos (WMI)
│   └── seguranca.py         # Processos suspeitos, Firewall
├── gui/
│   └── app.py               # Interface gráfica (CustomTkinter)
└── output/                  # Relatórios gerados automaticamente aqui
```

---

## ⚙️ Configuração de Regras (`config/rules.json`)

Você pode customizar os limites de **Aviso** e **Crítico** editando o arquivo:

```json
{
    "hardware": {
        "cpu_usage":   { "warning": 80.0,  "critical": 95.0 },
        "ram_usage":   { "warning": 85.0,  "critical": 95.0 },
        "disk_usage":  { "warning": 85.0,  "critical": 95.0 },
        "cpu_temperature": { "warning": 80.0, "critical": 90.0 }
    },
    "sistema": {
        "pending_updates_count": { "warning": 3, "critical": 10 }
    }
}
```

---

## 📊 Exemplo de Relatório JSON

```json
{
    "timestamp": "2026-04-26T10:04:16",
    "hostname": "MeuPC",
    "summary": {
        "total_itens": 16,
        "criticos": 0,
        "avisos": 1,
        "ok": 15
    },
    "categorias": {
        "hardware": [
            {
                "nome": "CPU Usage",
                "valor": "90.5",
                "categoria": "Hardware",
                "severidade": "Aviso",
                "descricao": "Uso atual da CPU: 90.5%",
                "impacto": "Performance"
            }
        ]
    }
}
```

---

## 📦 Gerar Executável Portátil (.exe)

Para distribuir sem precisar de Python instalado:

```bash
pip install pyinstaller
pyinstaller --noconfirm --onedir --windowed ^
    --add-data "config/rules.json;config" ^
    --name "PCHealthChecker" main.py
```

O executável será gerado em `dist/PCHealthChecker/`.

---

## 🛠️ Categorias de Varredura

| Categoria     | O que verifica                                              |
|---------------|-------------------------------------------------------------|
| **Hardware**  | CPU, RAM, Disco, GPU (NVIDIA), Temperaturas                 |
| **Sistema**   | Versão do OS, Uptime, Atualizações pendentes               |
| **Aplicativos**| Processos em execução, apps com alto consumo de RAM        |
| **Jogos**     | Launchers instalados (Steam, Epic, GOG) e em execução      |
| **Drivers**   | Total de drivers, drivers sem assinatura, status anormal   |
| **Segurança** | Processos suspeitos, status do Firewall do Windows         |

---

## 📋 Níveis de Severidade

| Nível      | Significado                                         |
|------------|-----------------------------------------------------|
| 🟢 **OK**      | Dentro dos parâmetros normais                   |
| 🟠 **Aviso**   | Atenção recomendada — pode impactar performance |
| 🔴 **Crítico** | Ação necessária — risco de falha ou segurança   |

---

*Desenvolvido com Python 3 · psutil · CustomTkinter · Pydantic · WMI*
