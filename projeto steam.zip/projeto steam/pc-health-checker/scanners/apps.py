import psutil
from typing import List
from core.models import ScanItem, Category

def scan_apps() -> List[ScanItem]:
    items = []
    
    # Processos em segundo plano
    process_count = len(psutil.pids())
    items.append(ScanItem(
        name="Background Processes",
        value=process_count,
        category=Category.APLICATIVOS,
        description=f"Total de processos rodando: {process_count}",
        impact="Performance"
    ))

    # Processos consumindo muita RAM (> 1GB)
    high_ram_processes = []
    for p in psutil.process_iter(['name', 'memory_info']):
        try:
            mem_info = p.info['memory_info']
            if mem_info and mem_info.rss > 1024 * 1024 * 1024:  # > 1GB
                high_ram_processes.append(p.info['name'])
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    if high_ram_processes:
        items.append(ScanItem(
            name="High RAM Apps",
            value=len(high_ram_processes),
            category=Category.APLICATIVOS,
            description=f"Apps usando > 1GB RAM: {', '.join(set(high_ram_processes))}",
            impact="Performance"
        ))

    return items
