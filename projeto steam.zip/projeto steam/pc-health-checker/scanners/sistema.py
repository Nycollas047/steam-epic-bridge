import platform
import psutil
from datetime import datetime
import time
from typing import List
from core.models import ScanItem, Category

def scan_sistema() -> List[ScanItem]:
    items = []
    
    # OS Info
    os_name = f"{platform.system()} {platform.release()}"
    items.append(ScanItem(
        name="Operating System",
        value=os_name,
        category=Category.SISTEMA,
        description=f"Versão: {platform.version()} / Arquitetura: {platform.machine()}"
    ))

    # Uptime
    boot_time = psutil.boot_time()
    uptime_seconds = time.time() - boot_time
    uptime_days = uptime_seconds / (24 * 3600)
    items.append(ScanItem(
        name="System Uptime",
        value=uptime_days,
        category=Category.SISTEMA,
        description=f"Tempo de atividade: {int(uptime_days)} dias, {int((uptime_seconds % (24 * 3600)) / 3600)} horas",
        impact="Estabilidade"
    ))

    # Windows specific checks (Registry, Updates) - placeholder
    if platform.system() == "Windows":
        # Simulating checking for pending updates or registry issues for now
        # A real implementation could use wmi or subprocess commands like:
        # subprocess.run(["powershell", "Get-WindowsUpdate"]) - Requires module
        items.append(ScanItem(
            name="Pending Updates",
            value=0, # Placeholder
            category=Category.SISTEMA,
            description="Verificação de atualizações pendentes do Windows (Simulado)",
            impact="Segurança"
        ))

    return items
