import platform
import sys
import io
from typing import List
from core.models import ScanItem, Category, Severity

def scan_drivers() -> List[ScanItem]:
    items = []

    if platform.system() != "Windows":
        items.append(ScanItem(
            name="Driver Check",
            value="N/A",
            category=Category.DRIVERS,
            description="Verificação de drivers via WMI só está disponível no Windows.",
        ))
        return items

    try:
        # Suprime o erro cosmético do WMI "Win32 exception occurred releasing IUnknown"
        # redirecionando stderr temporariamente
        _old_stderr = sys.stderr
        sys.stderr = io.StringIO()
        try:
            import wmi
            c = wmi.WMI()
            drivers = c.Win32_PnPSignedDriver()
        finally:
            sys.stderr = _old_stderr  # Restaura stderr sempre

        total = len(drivers)
        unsigned = [d for d in drivers if d.IsSigned is not None and not d.IsSigned]
        problematic = [d for d in drivers if d.Status and d.Status.lower() not in ("ok", "")]

        items.append(ScanItem(
            name="Total Drivers",
            value=total,
            category=Category.DRIVERS,
            description=f"Total de drivers instalados no sistema: {total}",
        ))

        if unsigned:
            names = ", ".join(d.DeviceName or "Desconhecido" for d in unsigned[:5])
            items.append(ScanItem(
                name="Unsigned Drivers",
                value=len(unsigned),
                category=Category.DRIVERS,
                severity=Severity.WARNING,
                description=f"Drivers sem assinatura digital ({len(unsigned)}): {names}",
                impact="Segurança"
            ))
        else:
            items.append(ScanItem(
                name="Unsigned Drivers",
                value=0,
                category=Category.DRIVERS,
                severity=Severity.OK,
                description="Todos os drivers estão assinados digitalmente.",
                impact="Segurança"
            ))

        if problematic:
            names = ", ".join(d.DeviceName or "Desconhecido" for d in problematic[:5])
            items.append(ScanItem(
                name="Problematic Drivers",
                value=len(problematic),
                category=Category.DRIVERS,
                severity=Severity.WARNING,
                description=f"Drivers com status anormal ({len(problematic)}): {names}",
                impact="Estabilidade"
            ))

    except ImportError:
        items.append(ScanItem(
            name="WMI Not Available",
            value="Não instalado",
            category=Category.DRIVERS,
            severity=Severity.WARNING,
            description="Módulo 'wmi' não instalado. Execute: pip install wmi",
        ))
    except Exception as e:
        items.append(ScanItem(
            name="Driver Scan Error",
            value="Erro",
            category=Category.DRIVERS,
            severity=Severity.WARNING,
            description=f"Erro ao verificar drivers: {e}",
        ))

    return items
