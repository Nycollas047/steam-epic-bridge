import psutil
from typing import List
from core.models import ScanItem, Category, Severity

def scan_hardware() -> List[ScanItem]:
    items = []

    # --- CPU ---
    try:
        cpu_percent = psutil.cpu_percent(interval=1)
        items.append(ScanItem(
            name="CPU Usage",
            value=cpu_percent,
            category=Category.HARDWARE,
            description=f"Uso atual da CPU: {cpu_percent:.1f}%",
            impact="Performance"
        ))
    except Exception as e:
        items.append(ScanItem(
            name="CPU Usage",
            value=-1,
            category=Category.HARDWARE,
            severity=Severity.WARNING,
            description=f"Não foi possível obter uso de CPU: {e}"
        ))

    # --- Frequência da CPU ---
    try:
        cpu_freq = psutil.cpu_freq()
        if cpu_freq:
            items.append(ScanItem(
                name="CPU Frequency",
                value=round(cpu_freq.current, 2),
                category=Category.HARDWARE,
                description=f"Frequência: {cpu_freq.current:.0f} MHz (Máx: {cpu_freq.max:.0f} MHz)",
                impact="Performance"
            ))
    except Exception:
        pass  # Nem sempre disponível, ignorar silenciosamente

    # --- Núcleos da CPU ---
    try:
        cores_logical = psutil.cpu_count(logical=True)
        cores_physical = psutil.cpu_count(logical=False)
        items.append(ScanItem(
            name="CPU Cores",
            value=cores_logical,
            category=Category.HARDWARE,
            description=f"Núcleos físicos: {cores_physical} | Lógicos (threads): {cores_logical}"
        ))
    except Exception:
        pass

    # --- RAM ---
    try:
        ram = psutil.virtual_memory()
        items.append(ScanItem(
            name="RAM Usage",
            value=ram.percent,
            category=Category.HARDWARE,
            description=f"RAM: {ram.percent:.1f}% usado ({ram.used / (1024**3):.1f} GB / {ram.total / (1024**3):.1f} GB)",
            impact="Performance"
        ))
    except Exception as e:
        items.append(ScanItem(
            name="RAM Usage",
            value=-1,
            category=Category.HARDWARE,
            severity=Severity.WARNING,
            description=f"Não foi possível obter dados de RAM: {e}"
        ))

    # --- Disco ---
    try:
        for part in psutil.disk_partitions(all=False):
            # Pula unidades de CD-ROM ou partições sem sistema de arquivos
            if not part.fstype or 'cdrom' in part.opts.lower():
                continue
            try:
                usage = psutil.disk_usage(part.mountpoint)
                device_label = part.device.replace("\\\\", "").replace("\\", "")
                items.append(ScanItem(
                    name=f"Disk Usage ({device_label})",
                    value=usage.percent,
                    category=Category.HARDWARE,
                    description=(
                        f"Disco {device_label} ({part.fstype}): {usage.percent:.1f}% usado "
                        f"({usage.used / (1024**3):.1f} GB / {usage.total / (1024**3):.1f} GB)"
                    ),
                    impact="Performance"
                ))
            except (PermissionError, OSError):
                pass  # Partição inacessível, ignorar
    except Exception as e:
        items.append(ScanItem(
            name="Disk Usage",
            value=-1,
            category=Category.HARDWARE,
            severity=Severity.WARNING,
            description=f"Erro ao ler discos: {e}"
        ))

    # --- Temperatura (Linux/macOS; no Windows requer WMI ou OpenHardwareMonitor) ---
    if hasattr(psutil, "sensors_temperatures"):
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                for sensor_name, entries in temps.items():
                    for entry in entries:
                        label = entry.label or sensor_name
                        if "core" in label.lower() or "cpu" in sensor_name.lower():
                            items.append(ScanItem(
                                name="CPU Temperature",
                                value=round(entry.current, 1),
                                category=Category.HARDWARE,
                                description=f"Temperatura ({label}): {entry.current:.1f}°C",
                                impact="Estabilidade"
                            ))
        except Exception:
            pass  # Sensores indisponíveis neste sistema

    # --- GPU via GPUtil (principalmente NVIDIA) ---
    try:
        import GPUtil
        gpus = GPUtil.getGPUs()
        for gpu in gpus:
            # Proteção contra valores None
            load = gpu.load if gpu.load is not None else 0.0
            temp = gpu.temperature if gpu.temperature is not None else 0.0
            mem_used = gpu.memoryUsed if gpu.memoryUsed is not None else 0
            mem_total = gpu.memoryTotal if gpu.memoryTotal is not None else 0

            items.append(ScanItem(
                name=f"GPU Load ({gpu.name})",
                value=round(load * 100, 1),
                category=Category.HARDWARE,
                description=f"GPU {gpu.name}: carga {load * 100:.1f}% | VRAM {mem_used:.0f}MB / {mem_total:.0f}MB",
                impact="Performance"
            ))
            if temp > 0:
                items.append(ScanItem(
                    name=f"GPU Temperature ({gpu.name})",
                    value=round(temp, 1),
                    category=Category.HARDWARE,
                    description=f"Temperatura GPU {gpu.name}: {temp:.1f}°C",
                    impact="Estabilidade"
                ))
    except ImportError:
        pass  # GPUtil não instalado — sem dados de GPU NVIDIA
    except Exception:
        pass  # GPU indisponível ou sem suporte

    return items
