import psutil
from typing import List
from core.models import ScanItem, Category, Severity

def scan_seguranca() -> List[ScanItem]:
    items = []

    suspicious_keywords = ['miner', 'hack', 'cheat', 'trojan', 'keylogger', 'rootkit']
    found_suspicious = []

    for p in psutil.process_iter(['name', 'pid']):
        try:
            proc_name = p.info.get('name')
            if not proc_name:  # Proteção: nome pode ser None
                continue
            if any(keyword in proc_name.lower() for keyword in suspicious_keywords):
                found_suspicious.append(f"{proc_name} (PID {p.info.get('pid', '?')})")
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    if found_suspicious:
        items.append(ScanItem(
            name="Suspicious Processes",
            value=len(found_suspicious),
            category=Category.SEGURANCA,
            severity=Severity.CRITICAL,
            description=f"Processos suspeitos detectados: {', '.join(set(found_suspicious))}",
            impact="Segurança"
        ))
    else:
        items.append(ScanItem(
            name="Suspicious Processes",
            value=0,
            category=Category.SEGURANCA,
            severity=Severity.OK,
            description="Nenhum processo suspeito detectado.",
            impact="Segurança"
        ))

    # --- Firewall (Windows via netsh) ---
    try:
        import subprocess
        result = subprocess.run(
            ["netsh", "advfirewall", "show", "allprofiles", "state"],
            capture_output=True, text=True, timeout=10
        )
        if "ON" in result.stdout.upper():
            items.append(ScanItem(
                name="Windows Firewall",
                value="Ativo",
                category=Category.SEGURANCA,
                severity=Severity.OK,
                description="Firewall do Windows está ativo.",
                impact="Segurança"
            ))
        elif result.returncode == 0:
            items.append(ScanItem(
                name="Windows Firewall",
                value="Inativo",
                category=Category.SEGURANCA,
                severity=Severity.CRITICAL,
                description="Firewall do Windows está DESATIVADO! Recomenda-se ativar.",
                impact="Segurança"
            ))
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
        pass  # Não disponível no Linux ou sem permissão

    return items
