import psutil
import os
from typing import List
from core.models import ScanItem, Category

def scan_jogos() -> List[ScanItem]:
    items = []
    
    # Check running launchers
    running_launchers = []
    launcher_names = ['steam.exe', 'epicgameslauncher.exe', 'galaxyclient.exe', 'battle.net.exe', 'origin.exe']
    
    for p in psutil.process_iter(['name']):
        try:
            if p.info['name'].lower() in launcher_names:
                running_launchers.append(p.info['name'])
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

    if running_launchers:
        items.append(ScanItem(
            name="Running Launchers",
            value=len(running_launchers),
            category=Category.JOGOS,
            description=f"Launchers ativos: {', '.join(set(running_launchers))}"
        ))

    # Basic check for default paths (Windows)
    default_paths = {
        "Steam": "C:\\Program Files (x86)\\Steam",
        "Epic Games": "C:\\Program Files\\Epic Games",
        "GOG Galaxy": "C:\\Program Files (x86)\\GOG Galaxy"
    }
    
    installed_launchers = []
    for name, path in default_paths.items():
        if os.path.exists(path):
            installed_launchers.append(name)
            
    if installed_launchers:
        items.append(ScanItem(
            name="Installed Launchers",
            value=len(installed_launchers),
            category=Category.JOGOS,
            description=f"Launchers detectados: {', '.join(installed_launchers)}"
        ))

    return items
