import socket
import os
import concurrent.futures
from typing import List, Callable
from .models import SystemHealthReport, ScanItem, Severity
from .classifier import Classifier
from .reporter import Reporter

# Caminho absoluto da raiz do projeto (onde engine.py está em /core/)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Engine:
    def __init__(self):
        rules_path = os.path.join(BASE_DIR, "config", "rules.json")
        output_dir = os.path.join(BASE_DIR, "output")
        self.classifier = Classifier(rules_path=rules_path)
        self.reporter = Reporter(output_dir=output_dir)
        self.scanners: List[Callable] = []

    def register_scanner(self, scanner_func: Callable):
        """Registra uma função de scanner que retorna uma lista de ScanItem."""
        self.scanners.append(scanner_func)

    def run_all(self) -> SystemHealthReport:
        try:
            hostname = socket.gethostname()
        except Exception:
            hostname = "Desconhecido"

        report = SystemHealthReport(hostname=hostname)
        all_items: List[ScanItem] = []

        if not self.scanners:
            return report

        # Executa os scanners em paralelo com timeout de 30s por scanner
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(len(self.scanners), 8)) as executor:
            future_to_name = {
                executor.submit(scanner): getattr(scanner, '__name__', str(scanner))
                for scanner in self.scanners
            }
            for future in concurrent.futures.as_completed(future_to_name, timeout=120):
                scanner_name = future_to_name[future]
                try:
                    items = future.result(timeout=30)
                    if items:
                        all_items.extend(items)
                except concurrent.futures.TimeoutError:
                    print(f"[AVISO] Scanner '{scanner_name}' excedeu o tempo limite.")
                except Exception as exc:
                    print(f"[ERRO] Scanner '{scanner_name}' falhou: {exc}")

        # Processa e classifica os itens
        for item in all_items:
            try:
                classified_item = self.classifier.classify_item(item)
                report.items.append(classified_item)

                # Atualiza categorias
                cat_name = classified_item.category.value.lower()
                if cat_name not in report.categories:
                    report.categories[cat_name] = []
                report.categories[cat_name].append(classified_item)
            except Exception as e:
                print(f"[ERRO] Falha ao classificar item '{item.name}': {e}")

        # Atualiza o resumo
        report.summary = {
            "total_itens": len(report.items),
            "criticos": sum(1 for i in report.items if i.severity == Severity.CRITICAL),
            "avisos": sum(1 for i in report.items if i.severity == Severity.WARNING),
            "ok": sum(1 for i in report.items if i.severity == Severity.OK),
        }

        return report
