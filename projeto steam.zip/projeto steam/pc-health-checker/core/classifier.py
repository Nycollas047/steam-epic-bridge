import json
import os
from .models import ScanItem, Severity

class Classifier:
    def __init__(self, rules_path: str = None):
        # Se não for passado caminho, tenta descobrir relativo ao arquivo atual
        if rules_path is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            rules_path = os.path.join(base_dir, "config", "rules.json")
        self.rules = self._load_rules(rules_path)

    def _load_rules(self, rules_path: str) -> dict:
        if os.path.exists(rules_path):
            try:
                with open(rules_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"[AVISO] Erro ao carregar regras de '{rules_path}': {e}")
        else:
            print(f"[AVISO] Arquivo de regras não encontrado: '{rules_path}'. Usando padrões internos.")
        return {}

    def classify_item(self, item: ScanItem) -> ScanItem:
        """Aplica regras de severidade baseadas na categoria e nome do item."""
        if not self.rules:
            return item

        # Tenta encontrar regras pela chave em inglês (category.name) ou em PT-BR (category.value)
        category_rules = (
            self.rules.get(item.category.name.lower(), {}) or
            self.rules.get(item.category.value.lower(), {})
        )

        if not category_rules:
            return item

        # Tenta combinar nome do item (case-insensitive, ignora espaços)
        item_key = item.name.lower().replace(" ", "_")
        item_rule = category_rules.get(item_key) or category_rules.get(item.name.lower())

        if item_rule and isinstance(item.value, (int, float)):
            try:
                critical_threshold = item_rule.get("critical", float('inf'))
                warning_threshold = item_rule.get("warning", float('inf'))
                if item.value >= critical_threshold:
                    item.severity = Severity.CRITICAL
                elif item.value >= warning_threshold:
                    item.severity = Severity.WARNING
            except (TypeError, ValueError):
                pass  # Valor não comparável, mantém severity padrão

        return item
