from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from enum import Enum
from datetime import datetime

class Severity(str, Enum):
    OK = "OK"
    WARNING = "Aviso"
    CRITICAL = "Crítico"

class Category(str, Enum):
    HARDWARE = "Hardware"
    SISTEMA = "Sistema"
    APLICATIVOS = "Aplicativos"
    JOGOS = "Jogos"
    DRIVERS = "Drivers"
    SEGURANCA = "Segurança"

class ScanItem(BaseModel):
    name: str = Field(..., description="Nome do item ou métrica")
    value: Any = Field(..., description="Valor medido ou detectado")
    category: Category = Field(..., description="Categoria do item")
    severity: Severity = Field(default=Severity.OK, description="Nível de severidade do item")
    description: Optional[str] = Field(None, description="Descrição detalhada ou recomendação")
    impact: Optional[str] = Field(None, description="Impacto (Performance, Segurança, Estabilidade)")

class SystemHealthReport(BaseModel):
    timestamp: datetime = Field(default_factory=datetime.now)
    hostname: str
    summary: Dict[str, int] = Field(default_factory=dict)
    items: List[ScanItem] = Field(default_factory=list)
    categories: Dict[str, List[ScanItem]] = Field(default_factory=dict)
