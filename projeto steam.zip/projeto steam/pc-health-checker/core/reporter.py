import json
import csv
import xml.etree.ElementTree as ET
from datetime import datetime
import os
from .models import SystemHealthReport, Severity

class Reporter:
    def __init__(self, output_dir: str = None):
        if output_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            output_dir = os.path.join(base_dir, "output")
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def _prepare_data(self, report: SystemHealthReport) -> dict:
        """Serializa o relatório para um dict JSON-safe."""
        data = {
            "timestamp": report.timestamp.isoformat(),
            "hostname": report.hostname,
            "summary": report.summary,
            "categorias": {},
        }

        for cat, items in report.categories.items():
            data["categorias"][cat] = []
            for item in items:
                data["categorias"][cat].append({
                    "nome": item.name,
                    "valor": str(item.value),
                    "categoria": item.category.value,
                    "severidade": item.severity.value,
                    "descricao": item.description or "",
                    "impacto": item.impact or "",
                })
        return data

    def export_json(self, report: SystemHealthReport, filename: str = None) -> str:
        if not filename:
            filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

        filepath = os.path.join(self.output_dir, filename)
        data = self._prepare_data(report)

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        return filepath

    def export_csv(self, report: SystemHealthReport, filename: str = None) -> str:
        if not filename:
            filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

        filepath = os.path.join(self.output_dir, filename)

        with open(filepath, 'w', newline='', encoding='utf-8-sig') as f:  # utf-8-sig para compatibilidade com Excel
            writer = csv.writer(f)
            writer.writerow(['Categoria', 'Nome', 'Valor', 'Severidade', 'Descrição', 'Impacto'])

            for item in report.items:
                writer.writerow([
                    item.category.value,
                    item.name,
                    str(item.value),
                    item.severity.value,
                    item.description or '',
                    item.impact or '',
                ])

        return filepath

    def export_xml(self, report: SystemHealthReport, filename: str = None) -> str:
        if not filename:
            filename = f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xml"

        filepath = os.path.join(self.output_dir, filename)

        root = ET.Element("SystemHealthReport")
        ET.SubElement(root, "Timestamp").text = report.timestamp.isoformat()
        ET.SubElement(root, "Hostname").text = report.hostname

        summary = ET.SubElement(root, "Resumo")
        for k, v in report.summary.items():
            ET.SubElement(summary, k).text = str(v)

        items_elem = ET.SubElement(root, "Itens")
        for item in report.items:
            item_elem = ET.SubElement(items_elem, "Item")
            ET.SubElement(item_elem, "Categoria").text = item.category.value
            ET.SubElement(item_elem, "Nome").text = item.name
            ET.SubElement(item_elem, "Valor").text = str(item.value)
            ET.SubElement(item_elem, "Severidade").text = item.severity.value
            ET.SubElement(item_elem, "Descricao").text = item.description or ""
            ET.SubElement(item_elem, "Impacto").text = item.impact or ""

        tree = ET.ElementTree(root)
        try:
            ET.indent(tree, space="\t", level=0)  # Python 3.9+
        except AttributeError:
            pass  # Versões mais antigas não têm ET.indent

        tree.write(filepath, encoding='utf-8', xml_declaration=True)
        return filepath
