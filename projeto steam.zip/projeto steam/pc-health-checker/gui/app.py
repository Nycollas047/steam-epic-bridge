import customtkinter as ctk
import threading
import os
from core.engine import Engine
from core.models import Severity
from scanners.hardware import scan_hardware
from scanners.sistema import scan_sistema
from scanners.apps import scan_apps
from scanners.jogos import scan_jogos
from scanners.drivers import scan_drivers
from scanners.seguranca import scan_seguranca

# Tema deve ser configurado ANTES de criar a janela
ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

SEV_COLORS = {
    Severity.CRITICAL: "#FF4C4C",
    Severity.WARNING:  "#FFA500",
    Severity.OK:       "#4CAF50",
}

class PCHealthCheckerApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("PC Health Checker")
        self.geometry("960x640")
        self.minsize(800, 520)

        self.engine = Engine()
        self._register_scanners()
        self.report = None

        self._build_ui()

    def _register_scanners(self):
        for scanner in [scan_hardware, scan_sistema, scan_apps, scan_jogos, scan_drivers, scan_seguranca]:
            self.engine.register_scanner(scanner)

    # ------------------------------------------------------------------ UI

    def _build_ui(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # === Sidebar ===
        self.sidebar = ctk.CTkFrame(self, width=210, corner_radius=0)
        self.sidebar.grid(row=0, column=0, sticky="nsew")
        self.sidebar.grid_propagate(False)
        self.sidebar.grid_rowconfigure(10, weight=1)  # empurra tudo para cima

        ctk.CTkLabel(
            self.sidebar, text="🖥 PC Health\nChecker",
            font=ctk.CTkFont(size=18, weight="bold"), justify="center"
        ).grid(row=0, column=0, padx=20, pady=(24, 20))

        self.btn_scan = ctk.CTkButton(
            self.sidebar, text="▶  Iniciar Varredura",
            font=ctk.CTkFont(size=14, weight="bold"),
            height=44, command=self.start_scan
        )
        self.btn_scan.grid(row=1, column=0, padx=16, pady=8, sticky="ew")

        ctk.CTkLabel(self.sidebar, text="Exportar Relatório", font=ctk.CTkFont(size=12)).grid(
            row=2, column=0, padx=20, pady=(16, 4), sticky="w"
        )

        self.btn_json = ctk.CTkButton(
            self.sidebar, text="📄  JSON", state="disabled",
            command=lambda: self._export("json")
        )
        self.btn_json.grid(row=3, column=0, padx=16, pady=4, sticky="ew")

        self.btn_csv = ctk.CTkButton(
            self.sidebar, text="📊  CSV", state="disabled",
            command=lambda: self._export("csv")
        )
        self.btn_csv.grid(row=4, column=0, padx=16, pady=4, sticky="ew")

        self.btn_xml = ctk.CTkButton(
            self.sidebar, text="🗂  XML", state="disabled",
            command=lambda: self._export("xml")
        )
        self.btn_xml.grid(row=5, column=0, padx=16, pady=4, sticky="ew")

        self.btn_open_folder = ctk.CTkButton(
            self.sidebar, text="📁  Abrir Pasta de Saída",
            fg_color="transparent", border_width=1,
            command=self._open_output_folder
        )
        self.btn_open_folder.grid(row=6, column=0, padx=16, pady=(12, 4), sticky="ew")

        # === Área principal ===
        self.main_frame = ctk.CTkFrame(self)
        self.main_frame.grid(row=0, column=1, padx=16, pady=16, sticky="nsew")
        self.main_frame.grid_rowconfigure(2, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)

        self.status_label = ctk.CTkLabel(
            self.main_frame, text="Pronto. Clique em 'Iniciar Varredura'.",
            font=ctk.CTkFont(size=15), anchor="w"
        )
        self.status_label.grid(row=0, column=0, padx=20, pady=(18, 6), sticky="ew")

        self.progress_bar = ctk.CTkProgressBar(self.main_frame)
        self.progress_bar.grid(row=1, column=0, padx=20, pady=(0, 10), sticky="ew")
        self.progress_bar.set(0)

        self.results_frame = ctk.CTkScrollableFrame(
            self.main_frame, label_text="Resultados"
        )
        self.results_frame.grid(row=2, column=0, padx=20, pady=(0, 16), sticky="nsew")
        self.results_frame.grid_columnconfigure(0, weight=1)

    # ------------------------------------------------------------------ Actions

    def start_scan(self):
        self.btn_scan.configure(state="disabled")
        self.btn_json.configure(state="disabled")
        self.btn_csv.configure(state="disabled")
        self.btn_xml.configure(state="disabled")
        self.status_label.configure(text="⏳ Varrendo sistema... Aguarde.")
        self.progress_bar.set(0)
        self.progress_bar.start()

        for w in self.results_frame.winfo_children():
            w.destroy()

        threading.Thread(target=self._scan_thread, daemon=True).start()

    def _scan_thread(self):
        try:
            self.report = self.engine.run_all()
        except Exception as e:
            self.report = None
            print(f"[ERRO] Falha na varredura: {e}")
        finally:
            self.after(0, self._scan_done)

    def _scan_done(self):
        self.progress_bar.stop()
        self.progress_bar.set(1)
        self.btn_scan.configure(state="normal")

        if self.report:
            s = self.report.summary
            self.status_label.configure(
                text=(
                    f"✅ Varredura concluída! "
                    f"{s['total_itens']} itens | "
                    f"🔴 Críticos: {s['criticos']} | "
                    f"🟠 Avisos: {s['avisos']} | "
                    f"🟢 OK: {s['ok']}"
                )
            )
            self.btn_json.configure(state="normal")
            self.btn_csv.configure(state="normal")
            self.btn_xml.configure(state="normal")
            self._display_results()
        else:
            self.status_label.configure(text="❌ Erro ao executar varredura. Verifique o terminal.")

    def _display_results(self):
        row = 0
        for cat, items in self.report.categories.items():
            # Cabeçalho da categoria
            header = ctk.CTkLabel(
                self.results_frame,
                text=f"  {cat.upper()}",
                font=ctk.CTkFont(size=13, weight="bold"),
                fg_color=("#2B2B2B", "#2B2B2B"),
                corner_radius=6,
                anchor="w",
            )
            header.grid(row=row, column=0, pady=(10, 4), padx=4, sticky="ew")
            row += 1

            for item in items:
                color = SEV_COLORS.get(item.severity, "white")
                badge = f"[{item.severity.value}]"
                desc = f"  {item.description}" if item.description else ""
                text = f"{badge}  {item.name}: {item.value}{desc}"

                lbl = ctk.CTkLabel(
                    self.results_frame,
                    text=text,
                    text_color=color,
                    justify="left",
                    anchor="w",
                    wraplength=680,
                )
                lbl.grid(row=row, column=0, pady=2, padx=12, sticky="ew")
                row += 1

    def _export(self, fmt: str):
        if not self.report:
            return
        try:
            if fmt == "json":
                path = self.engine.reporter.export_json(self.report)
            elif fmt == "csv":
                path = self.engine.reporter.export_csv(self.report)
            else:
                path = self.engine.reporter.export_xml(self.report)
            self.status_label.configure(text=f"✅ Relatório salvo: {path}")
        except Exception as e:
            self.status_label.configure(text=f"❌ Erro ao exportar: {e}")

    def _open_output_folder(self):
        folder = self.engine.reporter.output_dir
        if os.path.exists(folder):
            os.startfile(folder)  # Windows; no Linux usaria 'xdg-open'
        else:
            self.status_label.configure(text="Pasta de saída ainda não existe. Execute uma varredura primeiro.")

def run_app():
    app = PCHealthCheckerApp()
    app.mainloop()
